<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="TheAdmin - Responsive admin and web application ui kit">
    <meta name="keywords" content="admin, dashboard, web app, sass, ui kit, ui framework, bootstrap">

    <title>Peminjaman - SIM Inventaris</title>

    <!-- Styles -->
    <link href="../assets/css/core.min.css" rel="stylesheet">
    <link href="../assets/css/app.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">

    <!-- Favicons -->
    <link rel="apple-touch-icon" href="../assets/img/apple-touch-icon.png">
    <link rel="icon" href="../assets/img/favicon.png">
  </head>

  <body class="topbar-unfix">


    <!-- Topbar -->
   <header class="topbar topbar-expand-lg topbar-inverse bg-cyan" id="topbar-colors">
          <div class="topbar-left">
            <span class="topbar-btn topbar-menu-toggler"><i>&#9776;</i></span>
            <span class="topbar-brand"><span><font size='4'><i class="ti-reddit"></i> SIM Inventaris</font></span></span>

            <div class="topbar-divider d-none d-xl-block"></div>

            <nav class="topbar-navigation">
              <ul class="menu">

                <li class="menu-item active">
                  <a class="menu-link" href="home.php">
                    <span class="icon fa fa-sign-out"></span>
                    <span class="title">Peminjaman</span>
                  </a>
                </li>
              </ul>
            </nav>
          </div>
        </header>

    <!-- END Topbar -->



    <!-- Main container -->
    <main>
      <div class="main-content">
        <div class="container">
		<?php 
		include "modul/pinjam/form.php";
		?>
         </div>
      </div>





      <!-- Footer -->
      <footer class="site-footer">
       <div class="row">
          <div class="col-md-6">
            <p class="text-center text-md-left">Copyright © 2018 <a href=""></a>. Proyek UPK.</p>
          </div>
	
          <div class="col-md-6">
            <ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
              <li class="nav-item">
                <a class="nav-link" href="#">Ketentuan Layanan</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Bantuan</a>
              </li>
            </ul>
          </div>
        </div>
      </footer>
      <!-- END Footer -->


    </main>






    <!-- Scripts -->
    <script src="../assets/js/core.min.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="assets/js/script.js"></script>

  </body>
</html>
