<?php
switch(@$_GET['form']){
Default :
?>
<div class='row'>
          <div class="col-md-12">
            <div class="card">
              <h4 class="card-title">Data <strong>barang Peminjaman</strong></h4>
			  <div class="card-body">
			   <table id='coba' class="table table-striped table-bordered" cellspacing="0" data-provide="datatables">
              <thead>
                <tr>
                  <th>Kode</th>
				  <th>Nama</th>
                  <th>Spesifikasi</th>
                  <th>Kategori</th>
                  <th>Jumlah Tersedia</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from barang where jenis_barang = 'pinjaman'");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['kode_barang'];?></td>
				  <td><?= $data['nama_barang'];?></td>
				   <td><?= $data['spesifikasi'];?></td>
				   <td><?= $data['kategori'];?></td>
				   <td><?= $data['jumlah_total'];?></td>
				   <td class="text-center w-0px table-actions">
						<a class="border btn btn-danger btn-round" href="<?php echo "?form=detail-pinjam&id=".$data['kode_barang'];?>"><i class="fa fa-eye"> </i></a>
                      
					  </td>
					  </tr>
				  <?php
			  }
			  ?>
              </tbody>
            </table>
          </div>
        </div>
                 </div>
            </div>
		  
<?php
break;
case "detail-pinjam":
include "config/koneksi.php";
$q = $connect->query("select * from barang where kode_barang='$_GET[id]'");
$data= $q->fetch_assoc();
$q2 = $connect->query("select sum(jml_pinjam) as jumlah from pinjam_barang where kode_barang='$_GET[id]' and tgl_kembali='0000-00-00'");
$data2 = $q2->fetch_assoc();
$barang_pin= $data2['jumlah'];
if($data2['jumlah']==""){
	$barang_pin = "0";
}
$barang_ter = $data['jumlah_total'] - $barang_pin;
?>
<div class='row'>
<div class="col-md-6">
            <div class="card">
              <h4 class="card-title">Informasi Barang</h4>

              <div class="card-body">
			  
			  <div class="form-group row">
                  <label class="col-sm-8">Kode Barang</label>
                  <div class="col-sm-4">
                     <span><?= $data['kode_barang'];?></span>
                  </div>
                </div>
				
                 <div class="form-group row">
                  <label class="col-sm-8">Nama Barang</label>
                  <div class="col-sm-4">
                     <span><?= $data['nama_barang'];?><span>
                  </div>
                </div>
				
				
				
				<div class="form-group row">
                  <label class="col-sm-8">Spesifikasi</label>
                  <div class="col-sm-4">
                     <span><?= $data['spesifikasi'];?></span>
                  </div>
                </div>
				
                
				<a class='btn btn-cyan disabled' href="?form=ubah-barang&id=<?= $data['kode_barang'];?>">
				<i class='fa fa-edit'></i> Sunting Informasi </a>
				</div>
            </div>
          </div>
		  <div class="col-md-6">
            <div class="card">
              <h4 class="card-title">Jumlah Barang</h4>

              <div class="card-body">
                 <div class="form-group row">
                  <label class="col-sm-8">Jumlah barang tersedia</label>
                  <div class="col-sm-4">
                     <span><?= $barang_ter;?><span>
                  </div>
                </div>
				
				<div class="form-group row">
                  <label class="col-sm-8">Jumlah barang dipinjam</label>
                  <div class="col-sm-4">
                     <span><?= $barang_pin;?></span>
                  </div>
                </div>
				
				<div class="form-group row">
                  <label class="col-sm-8">Total Jumlah barang</label>
                  <div class="col-sm-4">
                     <span><?= $data['jumlah_total'];?></span>
                  </div>
                </div>
				<a class="btn btn-success 
				<?php if ($barang_ter<1){
					echo "disabled";
				}?>
				" href="?form=tambah-pinjam&id=<?= $_GET['id'];?>&jml=<?= $barang_ter;?>">
				<i class='fa fa-sign-in'></i> Pinjam </a>
				</div>
            </div>
          </div>
		  
		  </div>
		  <div class="col-md-12">
            <div class="card">
              <h4 class="card-title">Data <strong>Peminjaman</strong></h4>

              <div class="card-body">
			    <table id='coba' class="table table-striped table-bordered" cellspacing="0" data-provide="datatables">
              <thead>
                <tr>
                  <th>Kode</th>
				  <th>Tanggal pinjam</th>
                  <th>Jumlah</th>
                  <th>Peminjam</th>
				  <th>Tanggal Kembali</th>
				  <th>Keterangan</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from pinjam_barang where kode_barang='$_GET[id]' order by no_pinjam DESC");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['no_pinjam'];?></td>
				  <td><?= $data['tgl_pinjam'];?></td>
				   <td><?= $data['jml_pinjam'];?></td>
				   <td><?= $data['peminjam'];?></td>
				    <td><?php if ($data['keterangan']=="Dikembalikan"){
					echo $data['tgl_kembali'];}else{
					echo "-";
					}?></td>
					 <td><?= $data['keterangan'];?></td>
				   <td class="text-center w-0px table-actions">
				<a class="border btn btn-danger" title='Kembalikan' href="<?php echo "?form=tambah-pengembalian&id=".$data['no_pinjam'];?>"><i class="fa fa-sign-in"> </i></a> 
					  </td>
					  </tr>
				  <?php
			  }
			  ?>
              </tbody>
            </table>
          </div>
        </div>
                 </div>
            </div>
          </div>
<?php
break;
case "tambah-pinjam":
include "config/koneksi.php";
$q = $connect->query("select * from barang where kode_barang='$_GET[id]'");
$data= $q->fetch_assoc();
?>
<div class="col-lg-6">
            <form class="card" method='post' action='modul/pinjam/page.php?page=tambah-pinjam'>
              <h4 class="card-title"><strong>Pinjam Barang</strong></h4>

              <div class="card-body">
                <div class="form-group row">
                  <label class="col-sm-4">Kode Barang</label>
                  <div class="col-sm-8">
                    <span><?= $data['kode_barang'];?></span>
					<input type='hidden' name='kode' value="<?= $data['kode_barang'];?>">
					<input type='hidden' name='jml' value="<?= $_GET['jml'];?>">
					</div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-4">Nama barang</label>
                  <div class="col-sm-8">
                     <span><?= $data['nama_barang'];?></span>
					 <input type='hidden' name='nama' value="<?= $data['nama_barang'];?>">
                  </div>
                </div> 
				<div class="form-group row">
                  <label class="col-sm-4">Spesifikasi</label>
                  <div class="col-sm-8">
                     <span><?= $data['spesifikasi'];?></span>
					</div>
                </div>

				
               <div class="form-group row">
                  <label class="col-sm-4 col-form-label">Jumlah</label>
                  <div class="col-sm-8">
                    <input class="form-control" type="number" name='jumlah' required>
                  </div>
                </div>
				<div class="form-group row">
                  <label class="col-sm-4 col-form-label">Peminjam</label>
                  <div class="col-sm-8">
                    <input class="form-control" type="text" name='peminjam' required>
                  </div>
                </div>
				
				</div>
              <footer class="card-footer text-right">
                <a href='?form=barang' class="btn btn-danger">Batal</a>
                <button class="btn btn-primary" type="submit">Tambah</button>
              </footer>
            </form>
          </div>
		  
<?php
break;
case "tambah-pengembalian":
include "config/koneksi.php";
$q = $connect->query("select * from pinjam_barang,barang where barang.kode_barang=pinjam_barang.kode_barang and no_pinjam='$_GET[id]'");
$data= $q->fetch_assoc();
?>
<div class="col-lg-12">
            <form class="card" method='post' action='modul/pinjam/page.php?page=pengembalian'>
              <h4 class="card-title"><strong>Pengembalian Barang</strong></h4>

              <div class="card-body">
                <div class="form-group row">
                  <label class="col-sm-4">Kode Peminjaman</label>
                  <div class="col-sm-8">
                    <span><?= $data['no_pinjam'];?></span>
					<input type='hidden' name='kode' value="<?= $data['kode_barang'];?>">
					<input type='hidden' name='no' value="<?= $data['no_pinjam'];?>">
					</div>
                </div>
				<div class="form-group row">
                  <label class="col-sm-4">Tanggal Peminjaman</label>
                  <div class="col-sm-8">
                    <span><?= $data['tgl_pinjam'];?></span>
					<input type='hidden' name='kode' value="<?= $data['kode_barang'];?>">
					</div>
                </div>
				<div class="form-group row">
                  <label class="col-sm-4">Tanggal Kembali</label>
                  <div class="col-sm-8">
                    <span>
					<?php if($data['keterangan']=="Dikembalikan"){
						echo $data['tgl_kembali'];
					}else{
						echo "-";
					}
						?></span>
					<input type='hidden' name='kode' value="<?= $data['kode_barang'];?>">
					</div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-4">Nama barang</label>
                  <div class="col-sm-8">
                     <span><?= $data['nama_barang'];?></span>
					 <input type='hidden' name='nama' value="<?= $data['nama_barang'];?>">
                  </div>
                </div> 
				<div class="form-group row">
                  <label class="col-sm-4">Spesifikasi</label>
                  <div class="col-sm-8">
                     <span><?= $data['spesifikasi'];?></span>
					</div>
                </div>

				
               <div class="form-group row">
                  <label class="col-sm-4 col-form-label">Jumlah</label>
                  <div class="col-sm-8">
                      <span><?= $data['jml_pinjam'];?></span>
                  </div>
                </div>
				<div class="form-group row">
                  <label class="col-sm-4 col-form-label">Peminjam</label>
                  <div class="col-sm-8">
                    <span><?= $data['peminjam'];?></span>
                  </div>
                </div>
				<div class="form-group row">
                  <label class="col-sm-4 col-form-label">Keterangan Pengembalian</label>
                  <div class="col-sm-8">
                   <span><?= $data['keterangan'];?></span>
                  </div>
                </div>
				
				</div>
              <footer class="card-footer text-right">
                <a href='?form=barang' class="btn btn-danger">Batal</a>
                <button class="btn btn-primary
				<?php if($data['keterangan']=="Dikembalikan"){
						echo "disabled";
					}
				?>
				" type="submit">Kembalikan</button>
              </footer>
            </form>
          </div>
		  
<?php
break;
}
?> 	