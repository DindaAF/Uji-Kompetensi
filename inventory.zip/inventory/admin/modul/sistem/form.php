<?php
switch(@$_GET['form']){
	case "home":
	?>
	<div class='row'>
		   <div class="col-lg-6">
            <div class="card">
              <h4 class="card-title"><strong>Statistik</strong> Jenis Barang</h4>

              <div class="card-body">
                <canvas class="mx-auto" id="chart-pie" width="280" height="280"></canvas>
              </div>
            </div>
          </div> 
		<div class="col-lg-6">
            <div class="card">
              <h4 class="card-title"><strong>Kilas</strong> Aplikasi</h4>
			   <div class="card-body">
          ini adalah kilas aplikasi di file modul/sistem/form.php
			   </div>
			</div>
			</div>
		  </div>
	 <?php
	break;
	case "level":
?>
<div class='row'>
          <div class="col-md-12">
            <div class="card">
              <h4 class="card-title">Data <strong>Level</strong></h4>

              <div class="card-body">
			  <!-- Button trigger modal -->
                    <button class="btn btn-cyan" data-toggle="modal" data-target="#modal-default"><i class='fa fa-plus'></i> Tambah Level</button>

                    <!-- Modal -->
                    <div class="modal fade" id="modal-default" tabindex="-1">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title" id="myModalLabel">Masukkan Level baru</h4>
                            <button type="button" class="close" data-dismiss="modal">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
						  <form action='modul/sistem/page.php?page=tambah-level' method='post'>
                            <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-user"></i></span>
                  <input type="text" class="form-control" placeholder="level" name='level' required>
                </div>
						  </div>
                          <div class="modal-footer">
                            <button type="cancel" class="btn btn-bold btn-pure btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-bold btn-pure btn-primary">Tambahkan	</button>
                          
						  </div>
						  </form>
                        </div>
                      </div>
                    </div>
					<br><br>
			    <table id='coba' class="table table-striped table-bordered" cellspacing="0">
              <thead>
                <tr>
                  <th>Kode</th>
				  <th>Level</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from level");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['kode_level'];?></td>
				  <td><?= $data['level'];?></td>
				   <td class="text-center w-0px table-actions">
                       <a class="border btn btn-success btn-round" href="<?php echo "home.php?form=ubah-level&id=".$data['kode_level'];?>">Edit</a>
                       <a class="border btn btn-danger btn-round" href="<?php echo "modul/sistem/page.php?page=hapus-level&id=".$data['kode_level'];?>">Hapus</a>
                      
					  </td>
					  </tr>
				  <?php
			  }
			  ?>
              </tbody>
            </table>
          </div>
        </div>
                 </div>
            </div>
          </div>
		  </div>
	

<?php
break;
case "ubah-level":
include "config/koneksi.php";
$q = $connect->query("select * from level where kode_level='$_GET[id]'");
$data = $q->fetch_assoc();
?>
<div class='row'>
<div class='col-md-3'>
</div>
<div class='col-md-6'>
 <div class="card">
                            <h4 class="card-title">Ubah data level</h4>
                          <div class="card-body">
						  <form action='modul/sistem/page.php?page=ubah-level' method='post'>
						  <input type='hidden' name='id' value="<?=$_GET['id'];?>">
                            <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-user"></i></span>
                  <input type="text" class="form-control" placeholder="Level" name='level' value="<?= $data['level'];?>" required>
                </div>
                          </div>
                          <div class="modal-footer">
                            <button type="cancel" class="btn btn-bold btn-pure btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-bold btn-pure btn-primary">Ubah</button>
                          
						  </div>
						  </form>
                        </div>
                      </div>
					  
                    </div>
<?php
break;
case "menu":
?>
<div class='row'>
          <div class="col-md-12">
            <div class="card">
              <h4 class="card-title">Data <strong>menu</strong></h4>

              <div class="card-body">
			  <!-- Button trigger modal -->
                    <button class="btn btn-cyan" data-toggle="modal" data-target="#modal-default"><i class='fa fa-plus'></i> Tambah menu</button>

                    <!-- Modal -->
                    <div class="modal fade" id="modal-default" tabindex="-1">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title" id="myModalLabel">Masukkan menu baru</h4>
                            <button type="button" class="close" data-dismiss="modal">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
						  <form action='modul/sistem/page.php?page=tambah-menu' method='post'>
                            <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-user"></i></span>
                  <input type="text" class="form-control" placeholder="menu" name='menu' required>
                </div>
						  </div>
                          <div class="modal-footer">
                            <button type="cancel" class="btn btn-bold btn-pure btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-bold btn-pure btn-primary">Tambahkan	</button>
                          
						  </div>
						  </form>
                        </div>
                      </div>
                    </div>
					<br><br>
			    <table id='coba' class="table table-striped table-bordered" cellspacing="0">
              <thead>
                <tr>
                  <th>Kode</th>
				  <th>menu</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from menu");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['kode_menu'];?></td>
				  <td><?= $data['menu'];?></td>
				   <td class="text-center w-0px table-actions">
                       <a class="border btn btn-success btn-round" href="<?php echo "home.php?form=ubah-menu&id=".$data['kode_menu'];?>">Edit</a>
                       <a class="border btn btn-danger btn-round" href="<?php echo "modul/sistem/page.php?page=hapus-menu&id=".$data['kode_menu'];?>">Hapus</a>
                      
					  </td>
					  </tr>
				  <?php
			  }
			  ?>
              </tbody>
            </table>
          </div>
        </div>
                 </div>
            </div>
          </div>
		  </div>
	

<?php
break;
case "ubah-menu":
include "config/koneksi.php";
$q = $connect->query("select * from menu where kode_menu='$_GET[id]'");
$data = $q->fetch_assoc();
?>
<div class='row'>
<div class='col-md-3'>
</div>
<div class='col-md-6'>
 <div class="card">
                            <h4 class="card-title">Ubah data menu</h4>
                          <div class="card-body">
						  <form action='modul/sistem/page.php?page=ubah-menu' method='post'>
						  <input type='hidden' name='id' value="<?=$_GET['id'];?>">
                            <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-user"></i></span>
                  <input type="text" class="form-control" placeholder="menu" name='menu' value="<?= $data['menu'];?>" required>
                </div>
                          </div>
                          <div class="modal-footer">
                            <button type="cancel" class="btn btn-bold btn-pure btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-bold btn-pure btn-primary">Ubah</button>
                          
						  </div>
						  </form>
                        </div>
                      </div>
					  
                    </div>
<?php
break;
case "hak-akses":
?>
<div class='row'>
 <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from menu");
			  while($data=$q->fetch_assoc()){
			  ?>
          <div class="col-md-4">
            <div class="card">
              <header class="card-header">
                <h4 class="card-title"><?= $data['menu'];?></h4>
              </header>

              <div class="card-body">
                <table class="table table-separated">
                  <thead>
                    <tr>
                      <th>Level</th>
                      <th class="text-center w-100px">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
				   <?php
			  $q2 = $connect->query("select * from hak_akses,level where hak_akses.kode_level = level.kode_level and 
			  hak_akses.kode_menu='$data[kode_menu]'");
			  while($data2=$q2->fetch_assoc()){
				 
			  ?>
                    <tr>
                      
                      <td><?= $data2['level'];?></td>
                      <td class="text-center w-100px table-actions">
                       <a class="table-action hover-danger" href="modul/sistem/page.php?page=hapus-akses&id=<?= $data2['id'];?>"><i class="ti-trash"></i></a>
                       
                      </td>
                    </tr>
					<?php
			  }
			  ?>
                  </tbody>
                </table>
			   </div>

              <footer class="card-footer">
			   <form action='modul/sistem/page.php?page=tambah-akses' method='post'>
			   <input type='hidden' value="<?= $data['kode_menu'];?>" name='menu'>
                   <div class='row'>
				  
				   <div class="col-md-8">
				   <select title='Pilih Level' data-provide="selectpicker" data-live-search="true" name='level' class='form-control' required>
                 <?php
				 $q3 = $connect ->query("select * from level");
				 while($data3=$q3->fetch_assoc()){
					 echo "<option value=$data3[kode_level]>$data3[level]</option>";
				 }
				 ?>
                </select></div>
				  <div class='col-md-1'><button type="submit" class="btn btn-bold btn-primary"><i class='fa fa-plus'></i></button></div>
				</div>
				</form>
              </footer>
			  
            </div>
          </div>
<?php
			  }
			  ?>
			  </div>
			  <?php
break;
case "lokasi":
?>
<div class='row'>
          <div class="col-md-12">
            <div class="card">
              <h4 class="card-title">Data <strong>Lokasi</strong></h4>

              <div class="card-body">
			  <!-- Button trigger modal -->
                    <button class="btn btn-cyan" data-toggle="modal" data-target="#modal-default"><i class='fa fa-plus'></i> Tambah Lokasi</button>

                    <!-- Modal -->
                    <div class="modal fade" id="modal-default" tabindex="-1">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title" id="myModalLabel">Masukkan Lokasi baru</h4>
                            <button type="button" class="close" data-dismiss="modal">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
						  <form action='modul/sistem/page.php?page=tambah-lokasi' method='post'>
                            <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-location"></i></span>
                  <input type="text" class="form-control" placeholder="Lokasi" name='lokasi' required>
                </div>
						  </div>
                          <div class="modal-footer">
                            <button type="cancel" class="btn btn-bold btn-pure btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-bold btn-pure btn-primary">Tambahkan	</button>
                          
						  </div>
						  </form>
                        </div>
                      </div>
                    </div>
					<br><br>
			    <table id='coba' class="table table-striped table-bordered" cellspacing="0">
              <thead>
                <tr>
                  <th>Kode</th>
				  <th>Lokasi</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from lokasi");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['kode_lokasi'];?></td>
				  <td><?= $data['nama_lokasi'];?></td>
				   <td class="text-center w-0px table-actions">
                       <a class="border btn btn-success btn-round" href="<?php echo "home.php?form=ubah-lokasi&id=".$data['kode_lokasi'];?>">Edit</a>
                       <a class="border btn btn-danger btn-round" href="<?php echo "modul/sistem/page.php?page=hapus-lokasi&id=".$data['kode_lokasi'];?>">Hapus</a>
                      
					  </td>
					  </tr>
				  <?php
			  }
			  ?>
              </tbody>
            </table>
          </div>
        </div>
                 </div>
            </div>
          </div>
		  </div>
	

<?php
break;
case "ubah-lokasi":
include "config/koneksi.php";
$q = $connect->query("select * from lokasi where kode_lokasi='$_GET[id]'");
$data = $q->fetch_assoc();
?>
<div class='row'>
<div class='col-md-6'>
 <div class="card">
                            <h4 class="card-title">Ubah data Lokasi</h4>
                          <div class="card-body">
						  <form action='modul/sistem/page.php?page=ubah-lokasi' method='post'>
						  <input type='hidden' name='id' value="<?=$_GET['id'];?>">
                            <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-user"></i></span>
                  <input type="text" class="form-control" placeholder="menu" name='lokasi' value="<?= $data['nama_lokasi'];?>" required>
                </div>
                          </div>
                          <div class="modal-footer">
                            <button type="cancel" class="btn btn-bold btn-pure btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-bold btn-pure btn-primary">Ubah</button>
                          
						  </div>
						  </form>
                        </div>
                      </div>
					  
                    </div>
<?php
break;

case "sumber-dana":
?>
<div class='row'>
          <div class="col-md-12">
            <div class="card">
              <h4 class="card-title">Data <strong>Sumber Dana</strong></h4>

              <div class="card-body">
			  <!-- Button trigger modal -->
                    <button class="btn btn-cyan" data-toggle="modal" data-target="#modal-default"><i class='fa fa-plus'></i> Tambah Sumber Dana</button>

                    <!-- Modal -->
                    <div class="modal fade" id="modal-default" tabindex="-1">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title" id="myModalLabel">Masukkan Sumber Dana Baru</h4>
                            <button type="button" class="close" data-dismiss="modal">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
						  <form action='modul/sistem/page.php?page=tambah-dana' method='post'>
                            <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-location"></i></span>
                  <input type="text" class="form-control" placeholder="Sumber Dana" name='dana' required>
                </div>
						  </div>
                          <div class="modal-footer">
                            <button type="cancel" class="btn btn-bold btn-pure btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-bold btn-pure btn-primary">Tambahkan	</button>
                          
						  </div>
						  </form>
                        </div>
                      </div>
                    </div>
					<br><br>
			    <table id='coba' class="table table-striped table-bordered" cellspacing="0">
              <thead>
                <tr>
                  <th>Kode</th>
				  <th>Sumber Dana</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from sumber_dana");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['kode_dana'];?></td>
				  <td><?= $data['nama_sumber'];?></td>
				   <td class="text-center w-0px table-actions">
                       <a class="border btn btn-success btn-round" href="<?php echo "home.php?form=ubah-dana&id=".$data['kode_dana'];?>">Edit</a>
                       <a class="border btn btn-danger btn-round" href="<?php echo "modul/sistem/page.php?page=hapus-dana&id=".$data['kode_dana'];?>">Hapus</a>
                      
					  </td>
					  </tr>
				  <?php
			  }
			  ?>
              </tbody>
            </table>
          </div>
        </div>
                 </div>
            </div>
          </div>
		  </div>
	

<?php
break;
case "ubah-dana":
include "config/koneksi.php";
$q = $connect->query("select * from sumber_dana where kode_dana='$_GET[id]'");
$data = $q->fetch_assoc();
?>
<div class='row'>
<div class='col-md-6'>
 <div class="card">
                            <h4 class="card-title">Ubah data Sumber Dana</h4>
                          <div class="card-body">
						  <form action='modul/sistem/page.php?page=ubah-dana' method='post'>
						  <input type='hidden' name='id' value="<?=$_GET['id'];?>">
                            <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-user"></i></span>
                  <input type="text" class="form-control" placeholder="menu" name='dana' value="<?= $data['nama_sumber'];?>" required>
                </div>
                          </div>
                          <div class="modal-footer">
                            <button type="cancel" class="btn btn-bold btn-pure btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-bold btn-pure btn-primary">Ubah</button>
                          
						  </div>
						  </form>
                        </div>
                      </div>
					  
                    </div>
<?php
break;
//Kategori
case "kategori":
?>
<div class='row'>
          <div class="col-md-12">
            <div class="card">
              <h4 class="card-title">Data <strong>Kategori Barang</strong></h4>

              <div class="card-body">
			  <!-- Button trigger modal -->
                    <button class="btn btn-cyan" data-toggle="modal" data-target="#modal-default"><i class='fa fa-plus'></i> Tambah Kategori</button>

                    <!-- Modal -->
                    <div class="modal fade" id="modal-default" tabindex="-1">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title" id="myModalLabel">Masukkan Kategori Barang Baru</h4>
                            <button type="button" class="close" data-dismiss="modal">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
						  <form action='modul/sistem/page.php?page=tambah-kategori' method='post'>
                            <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-location"></i></span>
                  <input type="text" class="form-control" placeholder="Kategori" name='kategori' required>
                </div>
						  </div>
                          <div class="modal-footer">
                            <button type="cancel" class="btn btn-bold btn-pure btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-bold btn-pure btn-primary">Tambahkan	</button>
                          
						  </div>
						  </form>
                        </div>
                      </div>
                    </div>
					<br><br>
			    <table id='coba' class="table table-striped table-bordered" cellspacing="0">
              <thead>
                <tr>
                  <th>Kode</th>
				  <th>Kategori</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from kategori");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['kode_kategori'];?></td>
				  <td><?= $data['kategori'];?></td>
				   <td class="text-center w-0px table-actions">
                       <a class="border btn btn-success btn-round" href="<?php echo "home.php?form=ubah-kategori&id=".$data['kode_kategori'];?>">Edit</a>
                       <a class="border btn btn-danger btn-round" href="<?php echo "modul/sistem/page.php?page=hapus-kategori&id=".$data['kode_kategori'];?>">Hapus</a>
                      
					  </td>
					  </tr>
				  <?php
			  }
			  ?>
              </tbody>
            </table>
          </div>
        </div>
                 </div>
            </div>
          </div>
		  </div>
	

<?php
break;
case "ubah-kategori":
include "config/koneksi.php";
$q = $connect->query("select * from kategori where kode_kategori='$_GET[id]'");
$data = $q->fetch_assoc();
?>
<div class='row'>
<div class='col-md-6'>
 <div class="card">
                            <h4 class="card-title">Ubah data kategori</h4>
                          <div class="card-body">
						  <form action='modul/sistem/page.php?page=ubah-kategori' method='post'>
						  <input type='hidden' name='id' value="<?=$_GET['id'];?>">
                            <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-user"></i></span>
                  <input type="text" class="form-control" placeholder="Kategori" name='kategori' value="<?= $data['kategori'];?>" required>
                </div>
                          </div>
                          <div class="modal-footer">
                            <button type="cancel" class="btn btn-bold btn-pure btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-bold btn-pure btn-primary">Ubah</button>
                          
						  </div>
						  </form>
                        </div>
                      </div>
					  
                    </div>
<?php
break;
}
?>