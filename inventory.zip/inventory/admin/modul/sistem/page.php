<?php
switch(@$_GET['page']){
	case "tambah-level":
	include "../../engines/proses.php";
	$insert= new proses();
	$counter= new proses();
	$kode = $counter->counter('kode_level',"LVL");
	$data['level'] = $_POST['level'];
	$data['kode_level'] = $kode;
	$insert ->insert("level",$data,'../../home.php?form=level');
	break;
	case "hapus-level":
	include "../../engines/proses.php";
	$hapus = new proses;
	$id =$_GET['id'];
	$hapus ->delete("level","kode_level = '".$id."'",'level');
	break;
	case "ubah-level":
	include "../../engines/proses.php";
	$ubah = new proses;
	$id =$_POST['id'];
	$data['level'] = $_POST['level'];
	$ubah->update("level",$data,"kode_level = '".$id."'", "home.php?form=level");
	break;
	case "tambah-menu":
	include "../../engines/proses.php";
	$insert= new proses();
	$counter= new proses();
	$kode = $counter->counter('kode_menu',"LVL");
	$data['menu'] = $_POST['menu'];
	$data['kode_menu'] = $kode;
	$insert ->insert("menu",$data,'../../home.php?form=menu');
	break;
	case "hapus-menu":
	include "../../engines/proses.php";
	$hapus = new proses;
	$id =$_GET['id'];
	$hapus ->delete("menu","kode_menu = '".$id."'",'menu');
	break;
	case "ubah-menu":
	include "../../engines/proses.php";
	$ubah = new proses;
	$id =$_POST['id'];
	$data['menu'] = $_POST['menu'];
	$ubah->update("menu",$data,"kode_menu = '".$id."'", "home.php?form=menu");
	break;
	
	case "tambah-lokasi":
	include "../../engines/proses.php";
	$insert= new proses();
	$counter= new proses();
	$kode = $counter->counter('kode_lokasi',"L");
	$data['nama_lokasi'] = $_POST['lokasi'];
	$data['kode_lokasi'] = $kode;
	$insert ->insert("lokasi",$data,'../../home.php?form=lokasi');
	break;
	case "hapus-lokasi":
	include "../../engines/proses.php";
	$hapus = new proses;
	$id =$_GET['id'];
	$hapus ->delete("lokasi","kode_lokasi = '".$id."'",'lokasi');
	break;
	case "ubah-lokasi":
	include "../../engines/proses.php";
	$ubah = new proses;
	$id =$_POST['id'];
	$data['nama_lokasi'] = $_POST['lokasi'];
	$ubah->update("lokasi",$data,"kode_lokasi = '".$id."'", "home.php?form=lokasi");
	break;
	case "tambah-dana":
	include "../../engines/proses.php";
	$insert= new proses();
	$counter= new proses();
	$kode = $counter->counter('kode_dana',"S");
	$data['nama_sumber'] = $_POST['dana'];
	$data['kode_dana'] = $kode;
	$insert ->insert("sumber_dana",$data,'../../home.php?form=sumber-dana');
	break;
	case "hapus-dana":
	include "../../engines/proses.php";
	$hapus = new proses;
	$id =$_GET['id'];
	$hapus ->delete("sumber_dana","kode_dana = '".$id."'",'sumber-dana');
	break;
	case "ubah-dana":
	include "../../engines/proses.php";
	$ubah = new proses;
	$id =$_POST['id'];
	$data['nama_sumber'] = $_POST['dana'];
	$ubah->update("sumber_dana",$data,"kode_dana = '".$id."'", "home.php?form=sumber-dana");
	break;
	case "tambah-akses":
	include "../../engines/proses.php";
	$insert= new proses();
	$data['kode_level'] = $_POST['level'];
	$data['kode_menu'] = $_POST['menu'];
	$insert ->insert("hak_akses",$data,'../../home.php?form=hak-akses');
	break;
	case "hapus-akses":
	include "../../engines/proses.php";
	$hapus = new proses;
	$id =$_GET['id'];
	$hapus ->delete("hak_akses","id = '".$id."'",'hak-akses');
	break;
	case "logout":
	session_start();
	session_destroy();
	header("location:../../login.php");
	break;
	//kategori
	case "tambah-kategori":
	include "../../engines/proses.php";
	$insert= new proses();
	$counter= new proses();
	$kode = $counter->counter('kode_kategori',"K");
	$data['kategori'] = $_POST['kategori'];
	$data['kode_kategori'] = $kode;
	$insert ->insert("kategori",$data,'../../home.php?form=kategori');
	break;
	case "hapus-kategori":
	include "../../engines/proses.php";
	$hapus = new proses;
	$id =$_GET['id'];
	$hapus ->delete("kategori","kode_kategori = '".$id."'",'kategori');
	break;
	case "ubah-kategori":
	include "../../engines/proses.php";
	$ubah = new proses;
	$id =$_POST['id'];
	$data['kategori'] = $_POST['kategori'];
	$ubah->update("kategori",$data,"kode_kategori = '".$id."'", "home.php?form=kategori");
	break;
}
?>