<?php
switch(@$_GET['page']){
	case "tambah-barang":
	include "../../engines/proses.php";
	$insert= new proses();
	$counter= new proses();
	$kode = $counter->counter('kode_barang',"B");
	$data['nama_barang'] = $_POST['nama'];
	$data['spesifikasi'] = $_POST['spek'];
	$data['kategori'] = $_POST['kategori'];
	$data['jumlah_total'] = "0";
	$data['jenis_barang'] = $_POST['jenis'];
	$data['kode_barang'] = $kode;
	$insert ->insert("barang",$data,'../../home.php?form=barang');
	break;
	case "hapus-barang":
	include "../../engines/proses.php";
	$hapus = new proses;
	$id =$_GET['id'];
	$hapus ->delete("barang","kode_barang = '".$id."'",'barang');
	break;
	case "ubah-barang":
	include "../../engines/proses.php";
	$ubah = new proses;
	$id =$_POST['id'];
	$data['nama_barang'] = $_POST['nama'];
	$data['spesifikasi'] = $_POST['spek'];
	$data['kategori'] = $_POST['kategori'];
	$data['jenis_barang'] = $_POST['jenis'];
	$ubah->update("barang",$data,"kode_barang = '".$id."'", "home.php?form=barang");
	break;
		case "ubah-masuk":
	include "../../engines/proses.php";
	include "../../config/koneksi.php";
	$insert= new proses();
	$counter= new proses();
	$data['jumlah_masuk'] = $_POST['jumlah'];
	if ($data['jumlah_masuk']<=0){
		echo"<script>alert('Jumlah barang minimal 1');
		window.location='../../home.php?form=masuk-barang&id=$_POST[kode]';</script>";
	}else{
	$data['kode_barang'] = $_POST['kode'];
	$data['sumber_dana'] = $_POST['dana'];
	$data['tgl_masuk'] = date("Y-m-d");
	$data['kode_supplier'] = $_POST['supplier'];
	$insert->update("masuk_barang",$data,"id_masuk_barang = '".$_POST['id']."'", "");
	$da['jumlah_total'] = $_POST['jumlah_total_awal'] - $_POST['jumlah_awal'] + $_POST['jumlah'];
	$ubah = new proses();
	$ubah->update("barang",$da,"kode_barang = '".$data['kode_barang']."'", "home.php?form=detail-masuk&id=$_POST[kode]");
	}
	break;
	case "tambah-masuk-barang":
	include "../../engines/proses.php";
	include "../../config/koneksi.php";
	$insert= new proses();
	$counter= new proses();
	$kode = $counter->counter('id_masuk_barang',"M");
	$data['jumlah_masuk'] = $_POST['jumlah'];
	if ($data['jumlah_masuk']<=0){
		echo"<script>alert('Jumlah barang minimal 1');
		window.location='../../home.php?form=masuk-barang&id=$_POST[kode]';</script>";
	}else{
	$data['kode_barang'] = $_POST['kode'];
	$data['sumber_dana'] = $_POST['dana'];
	$data['tgl_masuk'] = date("Y-m-d");
	$data['kode_supplier'] = $_POST['supplier'];
	$data['id_masuk_barang'] = $kode;
	$insert ->insert("masuk_barang",$data,'../../home.php?form=barang');
	$da['jumlah_total'] = $_POST['jumlah_awal'] + $_POST['jumlah'];
	$ubah = new proses();
	$ubah->update("barang",$da,"kode_barang = '".$data['kode_barang']."'", "home.php?form=detail-masuk&id=$_POST[kode]");
	}
	break;
	case "hapus-masuk":
	include "../../engines/proses.php";
	$hapus = new proses;
	$id =$_GET['id'];
	$hapus ->delete("masuk_barang","id_masuk_barang = '".$id."'","detail-masuk&id=$_GET[kode]");
	break;
	case "tambah-distribusi":
	$cek = $_POST['bg'] - $_POST['jumlah'];
	if ($_POST['jumlah']<=0){
		echo"<script>alert('Jumlah barang minimal 1');
		window.location='../../home.php?form=tambah-distribusi&id=$_POST[kode]';</script>";
	}else{
	if ($cek<0){
		echo "<script> alert ('stok gudang kurang!');
		window.location='../../home.php?form=tambah-distribusi&id=$_POST[kode]';</script>";
	}else{
	include "../../engines/proses.php";
	include "../../config/koneksi.php";
	$insert= new proses();
	$counter= new proses();
	$kode = $counter->counter('kode_distribusi',"D");
	$data['jumlah'] = $_POST['jumlah'];
	$data['id_masuk_barang'] = $_POST['kode'];
	$data['lokasi'] = $_POST['lokasi'];
	$data['kondisi'] = $_POST['kondisi'];
	$data['kode_barang'] = $_POST['kode_brg'];
	$data['kode_distribusi'] = $kode.".".$_POST['kode_brg'].".".$_POST['kode'].".".$_POST['lokasi'].".".$_POST['dana'];
	$insert ->insert("distribusi_barang",$data,"../../home.php?form=detail-barang&id=$_POST[kode]");
	}
	}
	break;
	case "hapus-distribusi":
	include "../../engines/proses.php";
	$hapus = new proses;
	$id =$_GET['id'];
	$hapus ->delete("distribusi_barang","kode_distribusi = '".$id."'","detail-barang&id=$_GET[kode]");
	break;
	case "tambah-mutasi":
	include "../../engines/proses.php";
	if ($_POST['jumlah']<=0){
		echo"<script>alert('Jumlah barang minimal 1');
		window.location='../../home.php?form=mutasi&id=$_POST[kode]';</script>";
	}else{
	$insert= new proses();
	$counter= new proses();
	$kode = $counter->counter('id_barang_keluar',"B");
	$data['kode_distribusi'] = $_POST['kode'];
	$data['kode_barang'] = $_POST['kode_brg'];
	$data['penerima'] = $_POST['lokasi'];
	$data['tgl_keluar'] = date("Y-m-d");
	$data['jumlah_keluar'] = $_POST['jumlah'];
	$data['keperluan'] = $_POST['keperluan'];
	$data['id_masuk_barang'] = $_POST['masuk'];
	$data['id_barang_keluar'] = $kode;
	$insert ->insert("keluar_barang",$data,"../../home.php?form=detail-barang&id=$_POST[masuk]");
	$insert2 = new proses();
	$data2['jumlah'] = $_POST['jumlah'];
	$data2['id_masuk_barang'] = $_POST['masuk'];
	$data2['lokasi'] = $_POST['lokasi'];
	$data2['kondisi'] = $_POST['kondisi'];
	$data2['kode_barang'] = $_POST['kode_brg'];
	$counter2= new proses();
	$kode2 = $counter2->counter('kode_distribusi',"D");
	$data2['kode_distribusi'] = $kode2.".".$_POST['kode_brg'].".".$_POST['masuk'].".".$_POST['lokasi'].".".$_POST['dana'];
	$insert ->insert("distribusi_barang",$data2,"../../home.php?form=detail-barang&id=$_POST[masuk]");
	}
	break;
	
}
?>