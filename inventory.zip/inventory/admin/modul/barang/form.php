<?php
switch(@$_GET['form']){
	case "barang":
?>
<div class='row'>
          <div class="col-md-12">
            <div class="card">
              <h4 class="card-title">Data <strong>barang</strong></h4>

              <div class="card-body">
			  <div class='text-right'>
			<a href='?form=tambah-barang' class="btn btn-cyan"><i class='fa fa-plus'></i> Tambah barang</a><br><br>
			</div>
			  
			    <table id='coba' class="table table-striped table-bordered" cellspacing="0">
              <thead>
                <tr>
                  <th>Kode</th>
        				  <th>Nama</th>
                  <th>Spesifikasi</th>
                  <th>Kategori</th>
                  <th>Jenis</th>
                  <th>Jumlah</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from barang,kategori where kategori.kode_kategori=barang.kategori");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['kode_barang'];?></td>
				  <td><?= $data['nama_barang'];?></td>
				   <td><?= $data['spesifikasi'];?></td>
				   <td><?= $data['kategori'];?></td>
				   <td><?= $data['jenis_barang'];?></td>
				   <td><?= $data['jumlah_total'];?></td>
				   <td class="text-center w-0px table-actions">
						<a class="border btn btn-cyan btn-round" href="<?php echo "?form=detail-masuk&id=".$data['kode_barang'];?>">Lihat</a>
                        <div class="dropdown table-action">
                          <span class="dropdown-toggle no-caret hover-primary" data-toggle="dropdown"><i class="ti-more-alt rotate-90"></i></span>
                          <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="<?php echo "home.php?form=ubah-barang&id=".$data['kode_barang'];?>"><i class="fa fa-edit"></i> Ubah data</a>
                            <a class="dropdown-item" href="<?php echo "modul/barang/page.php?page=hapus-barang&id=".$data['kode_barang'];?>"><i class="fa fa-trash"></i> Hapus data</a>
                         
                          </div>
                        </div>
					  </td>
					  </tr>
				  <?php
			  }
			  ?>
              </tbody>
            </table>
          </div>
        </div>
                 </div>
            </div>
          </div>
		  </div>
	

<?php
break;
case "tambah-barang":
?>
<div class="col-12">
            <form class="card" method='post' action='modul/barang/page.php?page=tambah-barang'>
              <h4 class="card-title"><strong>Tambah Barang</strong></h4>

              <div class="card-body row">

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Nama Barang</label>
                    <input class="form-control" type="text" name='nama' required>
                  </div>

                  <div class="form-group">
                    <label>Spesifikasi</label>
                    <input class="form-control" type="text" name='spek' required>
                  </div>

                  
                </div>


                <div class="col-md-6">
                  <div class="form-group">
                    <label>Kategori</label>
                     <select data-provide="selectpicker" title="" data-live-search="true" name='kategori' class='form-control' required>
				  <?php
				  $q=$connect->query("select * from kategori");
				  while($data= $q->fetch_assoc()){
					  echo "<option value=$data[kode_kategori]>$data[kategori]</option>";
				  }
				  ?>
                </select></div>

                  <div class="form-group">
                    <label>Jenis Barang</label>
                    <select data-provide="selectpicker" data-live-search="true" name='jenis' class='form-control' required>
					<option>Tetap</option>
					<option>Pinjaman</option>
                </select> </div>
                </div>
              </div>

              <footer class="card-footer text-right">
                <a href="?form=barang" class="btn btn-secondary">Batal</a>
                <button class="btn btn-primary" type="submit">Tambah</button>
              </footer>
            </form>
          </div>

<?php
break;
case "ubah-barang":
include "config/koneksi.php";
$q = $connect->query("select * from barang where kode_barang='$_GET[id]'");
$data= $q->fetch_assoc();
?>
<div class="col-12">
            <form class="card" method='post' action='modul/barang/page.php?page=ubah-barang'>
			<input type='hidden' name='id' value="<?= $data['kode_barang'];?>">
            <input type='hidden' name='jumlah' value="<?= $data['jumlah'];?>">
              <h4 class="card-title"><strong>Tambah Barang</strong></h4>

              <div class="card-body row">

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Nama Barang</label>
                    <input class="form-control" type="text" name='nama' value="<?= $data['nama_barang'];?>" required>
                  </div>

                  <div class="form-group">
                    <label>Spesifikasi</label>
                    <input class="form-control" type="text" name='spek' value="<?= $data['spesifikasi'];?>" required>
                  </div>

                 
                </div>


                <div class="col-md-6">
                   <div class="form-group">
                    <label>Kategori</label>
                    <select data-provide="selectpicker" data-live-search="true" name='kategori' class='form-control' title="<?= $data['kategori'];?>" required>
					<option>Alat</option>
					<option>Bahan</option>
                </select></div>

                  <div class="form-group">
                    <label>Jenis Barang</label>
                    <select data-provide="selectpicker" data-live-search="true" name='jenis' class='form-control' value="<?= $data['jenis_barang'];?>" required>
					<option>Tetap</option>
					<option>Pinjaman</option>
                </select> </div>
                </div>
              </div>

              <footer class="card-footer text-right">
                <a href="?form=barang" class="btn btn-secondary">Batal</a>
                <button class="btn btn-primary" type="submit">Tambah</button>
              </footer>
            </form>
          </div>

<?php
break;
case "masuk-barang":
include "config/koneksi.php";
$q = $connect->query("select * from barang where kode_barang='$_GET[id]'");
$data= $q->fetch_assoc();
?>
<div class="col-lg-6">
            <form class="card" method='post' action='modul/barang/page.php?page=tambah-masuk-barang'>
              <h4 class="card-title"><strong>Masuk Barang</strong></h4>

              <div class="card-body">
                <div class="form-group row">
                  <label class="col-sm-4">Kode Barang</label>
                  <div class="col-sm-8">
                    <span><?= $data['kode_barang'];?></span>
					<input type='hidden' name='kode' value="<?= $data['kode_barang'];?>">
					<input type='hidden' name='jumlah_awal' value="<?= $data['jumlah_total'];?>">
					</div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-4">Nama barang</label>
                  <div class="col-sm-8">
                     <span><?= $data['nama_barang'];?></span>
					 <input type='hidden' name='nama' value="<?= $data['nama_barang'];?>">
                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-4 col-form-label">Supplier</label>
                  <div class="col-sm-8">
                    <select title='Pilih Supplier' data-provide="selectpicker" data-live-search="true" name='supplier' class='form-control'>
                 <?php
				 include "config/koneksi.php";
				 $q3 = $connect ->query("select * from supplier where kategori='$data[kategori]'");
				 while($data3=$q3->fetch_assoc()){
					 echo "<option value=$data3[kode_supplier]>$data3[nama_supplier]</option>";
				 }
				 ?>
                </select> </div>
                </div>
				
               <div class="form-group row">
                  <label class="col-sm-4 col-form-label">Jumlah</label>
                  <div class="col-sm-8">
                    <input class="form-control" type="number" name='jumlah' required>
                  </div>
                </div>
				
				
               <div class="form-group row">
                  <label class="col-sm-4 col-form-label">Sumber dana</label>
                  <div class="col-sm-8">
                     <select title='Sumber dana' data-provide="selectpicker" data-live-search="true" name='dana' class='form-control' required>
					 <?php
				 include "config/koneksi.php";
				 $q3 = $connect ->query("select * from sumber_dana");
				 while($data3=$q3->fetch_assoc()){
					 echo "<option value=$data3[kode_dana]>$data3[nama_sumber]</option>";
				 }
				 ?></select>
				</div>
                </div>
              </div>

              <footer class="card-footer text-right">
                <a href='?form=barang' class="btn btn-danger">Batal</a>
                <button class="btn btn-primary" type="submit">Tambah</button>
              </footer>
            </form>
          </div>
<?php
break;
case "ubah-masuk":
include "config/koneksi.php";
$q = $connect->query("select * from masuk_barang,barang,supplier,sumber_dana
 where masuk_barang.kode_barang=barang.kode_barang
 and masuk_barang.kode_supplier = supplier.kode_supplier
 and masuk_barang.sumber_dana = sumber_dana.kode_dana
and id_masuk_barang='$_GET[id]'");
$data= $q->fetch_assoc();
?>
<div class="col-lg-6">
            <form class="card" method='post' action='modul/barang/page.php?page=ubah-masuk'>
              <h4 class="card-title"><strong>Ubah Masuk Barang</strong></h4>
			<input type="hidden" name='id' value="<?= $data['id_masuk_barang'];?>">
              <div class="card-body">
                <div class="form-group row">
                  <label class="col-sm-4">Kode Barang</label>
                  <div class="col-sm-8">
                    <span><?= $data['kode_barang'];?></span>
					<input type='hidden' name='kode' value="<?= $data['kode_barang'];?>">
					<input type='hidden' name='jumlah_total_awal' value="<?= $data['jumlah_total'];?>">
					<input type='hidden' name='jumlah_awal' value="<?= $data['jumlah_masuk'];?>">
					</div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-4">Nama barang</label>
                  <div class="col-sm-8">
                     <span><?= $data['nama_barang'];?></span>
					 <input type='hidden' name='nama' value="<?= $data['nama_barang'];?>">
                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-4 col-form-label">Supplier</label>
                  <div class="col-sm-8">
                    <select title='Pilih Supplier' data-provide="selectpicker" data-live-search="true" name='supplier' class='form-control'>
                 <option value="<?= $data['kode_supplier'];?>" selected><?= $data['nama_supplier'];?></option>
				 <?php
				 include "config/koneksi.php";
				 $q3 = $connect ->query("select * from supplier where kategori='$data[kategori]'");
				 while($data3=$q3->fetch_assoc()){
					 echo "<option value=$data3[kode_supplier]>$data3[nama_supplier]</option>";
				 }
				 ?>
                </select> </div>
                </div>
				
               <div class="form-group row">
                  <label class="col-sm-4 col-form-label">Jumlah</label>
                  <div class="col-sm-8">
                    <input class="form-control" type="number" name='jumlah' value="<?= $data['jumlah_masuk'];?>" required>
                  </div>
                </div>
				
				
               <div class="form-group row">
                  <label class="col-sm-4 col-form-label">Sumber dana</label>
                  <div class="col-sm-8">
                     <select title='Sumber dana' data-provide="selectpicker" data-live-search="true" name='dana' class='form-control' required>
						 <option value="<?= $data['kode_dana'];?>" selected><?= $data['nama_sumber'];?></option>
					<?php
				 include "config/koneksi.php";
				 $q3 = $connect ->query("select * from sumber_dana");
				 while($data3=$q3->fetch_assoc()){
					 echo "<option value=$data3[kode_dana]>$data3[nama_sumber]</option>";
				 }
				 ?></select>
				</div>
                </div>
              </div>

              <footer class="card-footer text-right">
                <a href='?form=barang' class="btn btn-danger">Batal</a>
                <button class="btn btn-primary" type="submit">Ubah</button>
              </footer>
            </form>
          </div>
<?php
break;
case "detail-barang":
include "config/koneksi.php";
$q = $connect->query("select * from barang,masuk_barang where barang.kode_barang=masuk_barang.kode_barang and id_masuk_barang='$_GET[id]'");
$data= $q->fetch_assoc();
$q2 = $connect->query("select sum(jumlah) as jumlah from distribusi_barang where id_masuk_barang='$_GET[id]'");
$data2 = $q2->fetch_assoc();
$barang_dis= $data2['jumlah'];
if($data2['jumlah']==""){
	$barang_dis = "0";
}
$barang_gudang = $data['jumlah_masuk'] - $barang_dis;
?>
<div class='row'>
<div class="col-md-6">
            <div class="card">
              <h4 class="card-title">Informasi Barang</h4>

              <div class="card-body">
			  
			  <div class="form-group row">
                  <label class="col-sm-8">Kode Barang</label>
                  <div class="col-sm-4">
                     <span><?= $data['kode_barang'];?></span>
                  </div>
                </div>
				
                 <div class="form-group row">
                  <label class="col-sm-8">Nama Barang</label>
                  <div class="col-sm-4">
                     <span><?= $data['nama_barang'];?><span>
                  </div>
                </div>
				
				
				
				<div class="form-group row">
                  <label class="col-sm-8">Spesifikasi</label>
                  <div class="col-sm-4">
                     <span><?= $data['spesifikasi'];?></span>
                  </div>
                </div>
				
                
				<a class='btn btn-cyan' href="?form=ubah-barang&id=<?= $data['kode_barang'];?>">
				<i class='fa fa-edit'></i> Sunting Informasi </a>
				</div>
            </div>
          </div>
		  <div class="col-md-6">
            <div class="card">
              <h4 class="card-title">Jumlah Barang</h4>

              <div class="card-body">
                 <div class="form-group row">
                  <label class="col-sm-8">Jumlah barang di gudang</label>
                  <div class="col-sm-4">
                     <span><?= $barang_gudang;?><span>
                  </div>
                </div>
				
				<div class="form-group row">
                  <label class="col-sm-8">Jumlah barang terdistribusi</label>
                  <div class="col-sm-4">
                     <span><?= $barang_dis;?></span>
                  </div>
                </div>
				
				<div class="form-group row">
                  <label class="col-sm-8">Total Jumlah barang</label>
                  <div class="col-sm-4">
                     <span><?= $data['jumlah_masuk'];?></span>
                  </div>
                </div>
				<a class="btn btn-success 
				<?php if ($barang_gudang<1){
					echo "disabled";
				}?>
				" href="?form=tambah-distribusi&id=<?= $_GET['id'];?>">
				<i class='fa fa-sign-in'></i> Distribusikan </a>
				</div>
            </div>
          </div>
		  
		  </div>
 <div class="col-lg-12">
            <div class="card">
              <h5 class="card-title"><strong>Data Distribusi</strong></h5>
              <div class="card-body">
			  <div class='text-right'>
				<a href="print.php?form=distribusi&id=<?= $_GET['id'];?>" class="btn btn-danger"><i class='fa fa-history'></i> Cadangkan</a><br><br>
			</div>
				   <table id='coba' class="table table-striped table-bordered" cellspacing="0">
              <thead>
                <tr>
                  <th>Kode</th>
				  <th>Lokasi</th>
                  <th>Jumlah</th>
                  <th>Kondisi</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from distribusi_barang,lokasi where distribusi_barang.lokasi=lokasi.kode_lokasi and distribusi_barang.id_masuk_barang='$_GET[id]'");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['kode_distribusi'];?></td>
				  <td><?= $data['nama_lokasi'];?></td>
				   <td><?= $data['jumlah'];?></td>
				   <td><?= $data['kondisi'];?></td>
				   <td class="text-center w-0px table-actions">
						<a class="border btn btn-danger" href="<?php echo "?form=mutasi&id=".$data['kode_distribusi'];?>"><i class="fa fa-sign-out"> </i> Mutasikan</a> 
					  <a class="border btn btn-cyan" title='Cetak Label' href="<?php echo "print.php?form=print-label&id=".$data['kode_distribusi']."&jumlah=".$data['jumlah'];?>"><i class="fa fa-print"> </i></a> 
					  <div class="dropdown table-action">
                          <span class="dropdown-toggle no-caret hover-primary" data-toggle="dropdown"><i class="ti-more-alt rotate-90"></i></span>
                          <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="<?php echo "home.php?form=ubah-distribusi&kode=".$data['kode_distribusi']."&id=".$data['id_masuk_barang'];?>"><i class="fa fa-edit"></i> Ubah data</a>
                            <a class="dropdown-item" href="<?php echo "modul/barang/page.php?page=hapus-distribusi&id=".$data['kode_distribusi']."&kode=".$data['id_masuk_barang'];?>"><i class="fa fa-trash"></i> Hapus data</a>
                         
                          </div>
                        </div>
					  </td>
					  </tr>
				  <?php
			  }
			  ?>
              </tbody>
            </table>
                 
                    
				   </div>
                </div>
              </div>
			  <div class="card">
              <h5 class="card-title"><strong>Data Mutasi</strong></h5>

              <div class="card-body">
			  <table id='coba' class="table table-striped table-bordered" cellspacing="0">
              <thead>
                <tr>
				  <th>Kode</th>
                  <th>Jumlah</th>
                  <th>Penerima</th>
                  <th>tanggal</th>
				  <th>keperluan</th>
                </tr>
              </thead>
              <tbody>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from keluar_barang,lokasi where keluar_barang.penerima=lokasi.kode_lokasi and keluar_barang.id_masuk_barang='$_GET[id]'");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['kode_distribusi'];?></td>
				  <td><?= $data['jumlah_keluar'];?></td>
				   <td><?= $data['nama_lokasi'];?></td>
				   <td><?= $data['tgl_keluar'];?></td>
				   <td><?= $data['keperluan'];?></td>
				   
					  </tr>
				  <?php
			  }
			  ?>
              </tbody>
            </table>
			</div>
			</div>
			
            
<?php
break;
case "distribusi":
?>
<div class='row'>
          <div class="col-md-12">
            <div class="card">
              <h4 class="card-title">Data <strong>Masuk Barang</strong></h4>

              <div class="card-body">
			    <table id='coba' class="table table-striped table-bordered" cellspacing="0">
              <thead>
                <tr>
                  <th>Kode masuk</th>
				  <th>Tanggal Masuk</th>
				  <th>Nama</th>
                  <th>Spesifikasi</th>
                  <th>Kategori</th>
                  <th>Jumlah</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from barang,masuk_barang where barang.kode_barang=masuk_barang.kode_barang and jenis_barang = 'tetap'");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['id_masuk_barang'];?></td>
				  <td><?= $data['tgl_masuk'];?></td>
				  <td><?= $data['nama_barang'];?></td>
				   <td><?= $data['spesifikasi'];?></td>
				   <td><?= $data['kategori'];?></td>
				   <td><?= $data['jumlah_masuk'];?></td>
				   <td class="text-center w-0px table-actions">
						<a class="border btn btn-success btn-round" href="<?php echo "?form=detail-barang&id=".$data['id_masuk_barang'];?>">Lihat</a>
                      
					  </td>
					  </tr>
				  <?php
			  }
			  ?>
              </tbody>
            </table>
          </div>
        </div>
                 </div>
            </div>
		  
<?php
break;
case "ubah-distribusi":
include "config/koneksi.php";
$q = $connect->query("select * from barang,masuk_barang,sumber_dana where masuk_barang.sumber_dana=sumber_dana.kode_dana and barang.kode_barang=masuk_barang.kode_barang and id_masuk_barang='$_GET[id]'");
$data = $q->fetch_assoc();
$q2 = $connect->query("select sum(jumlah) as jumlah from distribusi_barang where id_masuk_barang='$_GET[id]'");
$data2 = $q2->fetch_assoc();
$barang_dis= $data2['jumlah'];
if($data2['jumlah']==""){
	$barang_dis = "0";
}
$barang_gudang = $data['jumlah_masuk'] - $barang_dis;		  ?>
<div class="col-lg-6">
            <form class="card" method='post' action='modul/barang/page.php?page=tambah-distribusi'>
              <h4 class="card-title"><strong>Distribusi Barang</strong></h4>

              <div class="card-body">
                <div class="form-group row">
                  <label class="col-sm-4">Kode Barang</label>
                  <div class="col-sm-8">
                    <span><?= $data['kode_barang'];?></span>
					<input type='hidden' name='kode' value="<?= $data['id_masuk_barang'];?>">
					<input type='hidden' name='kode_brg' value="<?= $data['kode_barang'];?>">
					
					</div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-4">Nama barang</label>
                  <div class="col-sm-8">
                     <span><?= $data['nama_barang'];?> (<?= $data['nama_sumber'];?>)</span>
					 <input type='hidden' name='dana' value="<?= $data['kode_dana'];?>">
                  </div>
                </div>
				<div class="form-group row">
                  <label class="col-sm-4">Jumlah barang gudang</label>
                  <div class="col-sm-8">
                     <span><?= $barang_gudang;?></span>
					 <input type='hidden' name='bg' value="<?= $barang_gudang;?>">
                  </div>
                </div>
				<?php
				include "config/koneksi.php";
				$q4 = $connect->query ("select * from distribusi_barang,lokasi where
				lokasi.kode_lokasi=distribusi_barang.lokasi
				and kode_distribusi='$_GET[kode]'");
				$data4 = $q4->fetch_assoc();
				?>
                <div class="form-group row">
                  <label class="col-sm-4 col-form-label">Lokasi</label>
                  <div class="col-sm-8">
				   <select title='Pilih Lokasi' data-provide="selectpicker" data-live-search="true" name='lokasi' class='form-control' required>
                 <option value="<?= $data4['kode_lokasi'];?>" selected><?= $data4['nama_lokasi'];?></option>
				 <?php
				 include "config/koneksi.php";
				 $q3 = $connect ->query("select * from lokasi");
				 while($data3=$q3->fetch_assoc()){
					 echo "<option value=$data3[kode_lokasi]>$data3[nama_lokasi]</option>";
				}
				 ?>
                </select></div>
                </div>
				
               <div class="form-group row">
                  <label class="col-sm-4 col-form-label">Jumlah</label>
                  <div class="col-sm-8">
                    <input class="form-control" type="number" name='jumlah' value="<?= $data4['jumlah'];?>" required>
                  </div>
                </div>
				
               <div class="form-group row">
                  <label class="col-sm-4 col-form-label">kondisi</label>
                  <div class="col-sm-8">
                     <select title='Pilih Kondisi' data-provide="selectpicker" data-live-search="true" name='kondisi' class='form-control' required>
					<option selected><?= $data4['kondisi'];?></option>
					<option>Baik</option>
					<option>Rusak</option>
                </select>
				</div>
                </div>
              </div>

              <footer class="card-footer text-right">
                <a href="?form=detail-barang&id=<?= $data['id_masuk_barang'];?>" class="btn btn-danger">Batal</a>
                <button class="btn btn-primary" type="submit">Ubah</button>
              </footer>
            </form>
          </div>
<?php
break;
case "tambah-distribusi":
include "config/koneksi.php";
$q = $connect->query("select * from barang,masuk_barang,sumber_dana where masuk_barang.sumber_dana=sumber_dana.kode_dana and barang.kode_barang=masuk_barang.kode_barang and id_masuk_barang='$_GET[id]'");
$data = $q->fetch_assoc();
$q2 = $connect->query("select sum(jumlah) as jumlah from distribusi_barang where id_masuk_barang='$_GET[id]'");
$data2 = $q2->fetch_assoc();
$barang_dis= $data2['jumlah'];
if($data2['jumlah']==""){
	$barang_dis = "0";
}
$barang_gudang = $data['jumlah_masuk'] - $barang_dis;
				  ?>
<div class="col-lg-6">
            <form class="card" method='post' action='modul/barang/page.php?page=tambah-distribusi'>
              <h4 class="card-title"><strong>Distribusi Barang</strong></h4>

              <div class="card-body">
                <div class="form-group row">
                  <label class="col-sm-4">Kode Barang</label>
                  <div class="col-sm-8">
                    <span><?= $data['kode_barang'];?></span>
					<input type='hidden' name='kode' value="<?= $data['id_masuk_barang'];?>">
					<input type='hidden' name='kode_brg' value="<?= $data['kode_barang'];?>">
					
					</div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-4">Nama barang</label>
                  <div class="col-sm-8">
                     <span><?= $data['nama_barang'];?> (<?= $data['nama_sumber'];?>)</span>
					 <input type='hidden' name='dana' value="<?= $data['kode_dana'];?>">
                  </div>
                </div>
				<div class="form-group row">
                  <label class="col-sm-4">Stok Digudang</label>
                  <div class="col-sm-8">
                     <span><?= $barang_gudang;?></span>
					 <input type='hidden' name='bg' value="<?= $barang_gudang;?>">
                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-4 col-form-label">Lokasi</label>
                  <div class="col-sm-8">
                   <select title='Pilih Lokasi' data-provide="selectpicker" data-live-search="true" name='lokasi' class='form-control' required>
                 <?php
				 include "config/koneksi.php";
				 $q3 = $connect ->query("select * from lokasi");
				 while($data3=$q3->fetch_assoc()){
					 echo "<option value=$data3[kode_lokasi]>$data3[nama_lokasi]</option>";
				}
				 ?>
                </select></div>
                </div>
				
               <div class="form-group row">
                  <label class="col-sm-4 col-form-label">Jumlah</label>
                  <div class="col-sm-8">
                    <input class="form-control" type="number" name='jumlah' required>
                  </div>
                </div>
				
               <div class="form-group row">
                  <label class="col-sm-4 col-form-label">kondisi</label>
                  <div class="col-sm-8">
                     <select title='Pilih Kondisi' data-provide="selectpicker" data-live-search="true" name='kondisi' class='form-control' required>
					<option>Baik</option>
					<option>Rusak</option>
                </select>
				</div>
                </div>
              </div>

              <footer class="card-footer text-right">
                <a href="?form=detail-barang&id=<?= $_GET['kode_barang'];?>" class="btn btn-danger">Batal</a>
                <button class="btn btn-primary" type="submit">Tambah</button>
              </footer>
            </form>
          </div>
<?php
break;
case "mutasi":
include "config/koneksi.php";
$q = $connect->query("select * from distribusi_barang,barang,masuk_barang,sumber_dana,lokasi
where sumber_dana.kode_dana=masuk_barang.sumber_dana 
and masuk_barang.id_masuk_barang=distribusi_barang.id_masuk_barang 
and masuk_barang.kode_barang=barang.kode_barang
and lokasi.kode_lokasi = distribusi_barang.lokasi
and kode_distribusi='$_GET[id]'");
$data = $q->fetch_assoc();
				  ?>
<div class="col-lg-6">
            <form class="card" method='post' action='modul/barang/page.php?page=tambah-mutasi'>
              <h4 class="card-title"><strong>Mutasi Barang</strong></h4>

              <div class="card-body">
                <div class="form-group row">
                  <label class="col-sm-4">Kode Distribusi Barang</label>
                  <div class="col-sm-8">
                    <span><?= $data['kode_distribusi'];?></span>
					<input type='hidden' name='kode' value="<?= $data['kode_distribusi'];?>">
					<input type='hidden' name='kode_brg' value="<?= $data['kode_barang'];?>">
					<input type='hidden' name='masuk' value="<?= $data['id_masuk_barang'];?>">
					<input type='hidden' name='jumlah_awal' value="<?= $data['jumlah'];?>">
					
					</div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-4">Nama barang</label>
                  <div class="col-sm-8">
                     <span><?= $data['nama_barang'];?> (<?= $data['nama_sumber'];?>)</span>
					 <input type='hidden' name='dana' value="<?= $data['sumber_dana'];?>">
                  </div>
                </div>
				<div class="form-group row">
                  <label class="col-sm-4">Jumlah Barang di tempat</label>
                  <div class="col-sm-8">
                     <span><?= $data['jumlah'];?> (<?=$data['nama_lokasi'];?>)</span>
					 <input type='hidden' name='bg' value="<?= $data['jumlah_masuk'];?>">
                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-4 col-form-label">Lokasi Mutasi</label>
                  <div class="col-sm-8">
                   <select title='Pilih Lokasi' data-provide="selectpicker" data-live-search="true" name='lokasi' class='form-control'>
                 <?php
				 include "config/koneksi.php";
				 $q3 = $connect ->query("select * from lokasi");
				 while($data3=$q3->fetch_assoc()){
					 echo "<option value=$data3[kode_lokasi]>$data3[nama_lokasi]</option>";
				}
				 ?>
                </select></div>
                </div>
				
               <div class="form-group row">
                  <label class="col-sm-4 col-form-label">Jumlah</label>
                  <div class="col-sm-8">
                    <input class="form-control" type="number" name='jumlah' required>
                  </div>
                </div>
				<div class="form-group row">
                  <label class="col-sm-4 col-form-label">Keperluan</label>
                  <div class="col-sm-8">
                    <input class="form-control" type="text" name='keperluan' required>
                  </div>
                </div>
				 <div class="form-group row">
                  <label class="col-sm-4 col-form-label">kondisi</label>
                  <div class="col-sm-8">
                     <select title='Pilih Kondisi' data-provide="selectpicker" data-live-search="true" name='kondisi' class='form-control' required>
					<option>Baik</option>
					<option>Rusak</option>
                </select>
				</div>
                </div>
              </div>

              <footer class="card-footer text-right">
                <a href="?form=detail-barang&id=<?= $_GET['kode_barang'];?>" class="btn btn-danger">Batal</a>
                <button class="btn btn-primary" type="submit">Tambah</button>
              </footer>
            </form>
          </div>
<?php
break;
case "detail-masuk":
include "config/koneksi.php";
$q = $connect->query("select * from barang,masuk_barang where barang.kode_barang=masuk_barang.kode_barang and barang.kode_barang='$_GET[id]'");
$data= $q->fetch_assoc();
$qb = $connect->query("select * from barang where kode_barang='$_GET[id]'");
$datab= $qb->fetch_assoc();
if ($datab['jenis_barang']=='Pinjaman'){
$q2 = $connect->query("select sum(jml_pinjam) as jumlah from pinjam_barang where kode_barang='$_GET[id]' and tgl_kembali='0000-00-00'");
$data2 = $q2->fetch_assoc();
$barang_pin= $data2['jumlah'];
if($data2['jumlah']==""){
	$barang_pin = "0";
}
$barang_ter = $data['jumlah_total'] - $barang_pin;
}else{
	$q2 = $connect->query("select sum(jumlah) as jumlah from distribusi_barang where kode_barang='$_GET[id]'");
$data2 = $q2->fetch_assoc();
$barang_dis= $data2['jumlah'];
if($data2['jumlah']==""){
	$barang_dis = "0";
}
$barang_gudang = $data['jumlah_total'] - $barang_dis;
}
?>
<div class='row'>
<div class="col-md-6">
            <div class="card">
              <h4 class="card-title">Informasi Barang</h4>

              <div class="card-body">
			  
			  <div class="form-group row">
                  <label class="col-sm-8">Kode Barang</label>
                  <div class="col-sm-4">
                     <span><?= $datab['kode_barang'];?></span>
                  </div>
                </div>
				
                 <div class="form-group row">
                  <label class="col-sm-8">Nama Barang</label>
                  <div class="col-sm-4">
                     <span><?= $datab['nama_barang'];?><span>
                  </div>
                </div>
				
				
				
				<div class="form-group row">
                  <label class="col-sm-8">Spesifikasi</label>
                  <div class="col-sm-4">
                     <span><?= $datab['spesifikasi'];?></span>
                  </div>
                </div>
				
                
				<a class='btn btn-cyan' href="?form=ubah-barang&id=<?= $data['kode_barang'];?>">
				<i class='fa fa-edit'></i> Sunting Informasi </a>
				</div>
            </div>
          </div>
		  <div class="col-md-6">
            <div class="card">
              <h4 class="card-title">Jumlah Barang</h4>
			<?php
			if ($datab['jenis_barang']=='Pinjaman'){
				?>
              <div class="card-body">
                 <div class="form-group row">
                  <label class="col-sm-8">Jumlah barang tersedia</label>
                  <div class="col-sm-4">
                     <span><?= $barang_ter;?><span>
                  </div>
                </div>
				
				<div class="form-group row">
                  <label class="col-sm-8">Jumlah barang dipinjam</label>
                  <div class="col-sm-4">
                     <span><?= $barang_pin;?></span>
                  </div>
                </div>
				
				<div class="form-group row">
                  <label class="col-sm-8">Total Jumlah barang</label>
                  <div class="col-sm-4">
                     <span><?= $data['jumlah_total'];?></span>
                  </div>
                </div>
				<a class="btn btn-success"
				 href="<?php echo "?form=masuk-barang&id=".$_GET['id'];?>">
				<i class='fa fa-sign-in'></i> Masuk Barang </a>
				</div>
				<?php
			}else{
					?>
					 <div class="card-body">
                 <div class="form-group row">
                  <label class="col-sm-8">Jumlah barang di gudang</label>
                  <div class="col-sm-4">
                     <span><?= $barang_gudang;?><span>
                  </div>
                </div>
				
				<div class="form-group row">
                  <label class="col-sm-8">Jumlah barang terdistribusi</label>
                  <div class="col-sm-4">
                     <span><?= $barang_dis;?></span>
                  </div>
                </div>
				
				<div class="form-group row">
                  <label class="col-sm-8">Total Jumlah barang</label>
                  <div class="col-sm-4">
                     <span><?= $data['jumlah_total'];?></span>
                  </div>
                </div>
				<a class="btn btn-success"
				 href="<?php echo "?form=masuk-barang&id=".$_GET['id'];?>">
				<i class='fa fa-sign-in'></i> Masuk Barang </a>
				</div>
            </div>
					<?php
				}
				?>
            </div>
          </div>
		  
		  </div>
		  <div class="col-md-12">
            <div class="card">
              <h4 class="card-title">Data <strong>Masuk Barang</strong></h4>

              <div class="card-body">
			    <table id='coba' class="table table-striped table-bordered" cellspacing="0">
              <thead>
                <tr>
                  <th>Kode</th>
				  <th>Tanggal</th>
                  <th>Jumlah</th>
                  <th>Supplier</th>
                  <th>Sumber Dana</th>
				  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from masuk_barang,supplier,sumber_dana where
									masuk_barang.kode_supplier=supplier.kode_supplier
									and masuk_barang.sumber_dana=sumber_dana.kode_dana
									and kode_barang='$_GET[id]'");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['id_masuk_barang'];?></td>
				  <td><?= $data['tgl_masuk'];?></td>
				   <td><?= $data['jumlah_masuk'];?></td>
				   <td><?= $data['nama_supplier'];?></td>
				    <td><?= $data['nama_sumber'];?></td>
					<td>
					<a onclick="return confirm('Dengan mengubah barang ini, maka distribusi atau peminjaman yang berhubungan dengan barang ini akan terhapus!!');"class="border btn btn-cyan" href="<?php echo "?form=ubah-masuk&id=".$data['id_masuk_barang'];?>"><i class="fa fa-edit"> </i></a>
                    <a onclick="return confirm('Dengan menghapus barang ini, maka distribusi atau peminjaman yang berhubungan dengan barang ini akan terhapus!!');" class="border btn btn-danger" href="<?php echo "modul/barang/page.php?page=hapus-masuk&kode=".$data['kode_barang']."&id=".$data['id_masuk_barang'];?>"><i class="fa fa-trash"> </i></a>
                       
						</td>
					  </tr>
				  <?php
			  }
			  ?>
              </tbody>
            </table>
          </div>
        </div>
                 </div>
            </div>
          </div>
<?php
break;
}
?>