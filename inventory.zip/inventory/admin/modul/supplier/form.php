<?php
switch(@$_GET['form']){
	case "supplier":
?>
<div class='row'>
          <div class="col-md-12">
            <div class="card">
              <h4 class="card-title">Data <strong>supplier</strong></h4>

              <div class="card-body">
			  <!-- Button trigger modal -->
                    <button class="btn btn-cyan" data-toggle="modal" data-target="#modal-default"><i class='fa fa-plus'></i> Tambah Supplier</button>

                    <!-- Modal -->
                    <div class="modal fade" id="modal-default" tabindex="-1">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title" id="myModalLabel">Masukkan data supplier baru</h4>
                            <button type="button" class="close" data-dismiss="modal">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
						  <form action='modul/supplier/page.php?page=tambah-supplier' method='post'>
                            <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-user"></i></span>
                  <input type="text" class="form-control" placeholder="Nama" name='nama' required>
                </div>

                <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-home"></i></span>
                  <input type="text" class="form-control" placeholder="Alamat" name='alamat' required>
                </div>

                <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-phone"></i></span>
                  <input type="text" class="form-control" placeholder="Nomor Telepon" name='telp' required>
                </div>
				  <div class="form-group input-group">
                  <select title='Kota Supplier' data-provide="selectpicker" data-live-search="true" name='kota' class='form-control'>
                  <option>Semarang</option>
				  <option>Boyolali</option>
                </select>
				</div>
				
				 <select title='Kategori Barang' data-provide="selectpicker" data-live-search="true" name='kategori' class='form-control' required>
                  <?php
				  $q=$connect->query("select * from kategori");
				  while($data= $q->fetch_assoc()){
					  echo "<option value=$data[kode_kategori]>$data[kategori]</option>";
				  }
				  ?>
                </select>
                          
						  </div>
                          <div class="modal-footer">
                            <button type="cancel" class="btn btn-bold btn-pure btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-bold btn-pure btn-primary">Tambahkan	</button>
                          
						  </div>
						  </form>
                        </div>
                      </div>
                    </div>
					<br><br>
			    <table id='coba' class="table table-striped table-bordered" cellspacing="0">
              <thead>
                <tr>
                  <th>Kode</th>
				  <th>Nama</th>
                  <th>Alamat</th>
                  <th>Telepon</th>
                  <th>Kota</th>
                  <th>Kategori</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from supplier,kategori where kategori.kode_kategori=supplier.kategori");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['kode_supplier'];?></td>
				  <td><?= $data['nama_supplier'];?></td>
				   <td><?= $data['alamat_supplier'];?></td>
				   <td><?= $data['telp_supplier'];?></td>
				   <td><?= $data['kota_supplier'];?></td>
				    <td><?= $data['kategori'];?></td>
				   <td class="text-center w-0px table-actions">
                       <a class="border btn btn-success btn-round" href="<?php echo "home.php?form=ubah-supplier&id=".$data['kode_supplier'];?>">Edit</a>
                       <a class="border btn btn-danger btn-round" href="<?php echo "modul/supplier/page.php?page=hapus-supplier&id=".$data['kode_supplier'];?>">Hapus</a>
                       
					  </td>
					  </tr>
				  <?php
			  }
			  ?>
              </tbody>
            </table>
          </div>
        </div>
                 </div>
            </div>
          </div>
		  </div>
	

<?php
break;
case "ubah-supplier":
include "config/koneksi.php";
$q = $connect->query("select * from supplier,kategori where kategori.kode_kategori = supplier.kategori and kode_supplier='$_GET[id]'");
$data = $q->fetch_assoc();
?>
<div class='row'>
<div class='col-md-3'>
</div>
<div class='col-md-6'>
 <div class="card">
                            <h4 class="card-title">Ubah data supplier</h4>
                          <div class="card-body">
						  <form action='modul/supplier/page.php?page=ubah-supplier' method='post'>
						  <input type='hidden' name='id' value="<?=$_GET['id'];?>">
                            <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-user"></i></span>
                  <input type="text" class="form-control" placeholder="Nama" name='nama' value="<?= $data['nama_supplier'];?>" required>
                </div>

                <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-home"></i></span>
                  <input type="text" class="form-control" placeholder="Alamat" name='alamat' value="<?= $data['alamat_supplier'];?>" required>
                </div>

                <div class="form-group input-group">
                  <span class="input-group-addon w-40px"><i class="fa fa-phone"></i></span>
                  <input type="text" class="form-control" placeholder="Nomor Telepon" name='telp' value="<?= $data['telp_supplier'];?>" required>
                </div>
				<div class="form-group">
                     <select data-provide="selectpicker" title="" data-live-search="true" name='kategori' class='form-control' required>
				  <?php
				  $q=$connect->query("select * from kategori");
				  echo "<option value=$data[kategori] selected>$data[kategori]</option>";
				  while($data2= $q->fetch_assoc()){
					  echo "<option value=$data2[kode_kategori]>$data2[kategori]</option>";
				  }
				  ?>
                </select></div>
                  <select title='Kota Supplier' data-provide="selectpicker" data-live-search="true" name='kota' class='form-control' value="<?= $data['kota_supplier'];?>" required>
					<?php
					echo "<option value='$data[kota_supplier]' selected>$data[kota_supplier]</option>";
					?>
				  <option>Semarang</option>
				  <option>Boyolali</option>
                </select>
                          </div>
                          <div class="modal-footer">
                            <button type="cancel" class="btn btn-bold btn-pure btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-bold btn-pure btn-primary">Ubah</button>
                          
						  </div>
						  </form>
                        </div>
                      </div>
					  
                    </div>
<?php
}
?>