<?php
switch(@$_GET['page']){
	case "tambah-supplier":
	include "../../engines/proses.php";
	$insert= new proses();
	$counter= new proses();
	$kode = $counter->counter('kode_supplier',"S");
	$data['nama_supplier'] = $_POST['nama'];
	$data['alamat_supplier'] = $_POST['alamat'];
	$data['telp_supplier'] = $_POST['telp'];
	$data['kota_supplier'] = $_POST['kota'];
	$data['kode_supplier'] = $kode;
	$data['kategori'] = $_POST['kategori'];
	$insert ->insert("supplier",$data,'../../home.php?form=supplier');
	break;
	case "hapus-supplier":
	include "../../engines/proses.php";
	$hapus = new proses;
	$id =$_GET['id'];
	$hapus ->delete("supplier","kode_supplier = '".$id."'",'supplier');
	break;
	case "ubah-supplier":
	include "../../engines/proses.php";
	$ubah = new proses;
	$id =$_POST['id'];
	$data['nama_supplier'] = $_POST['nama'];
	$data['alamat_supplier'] = $_POST['alamat'];
	$data['telp_supplier'] = $_POST['telp'];
	$data['kota_supplier'] = $_POST['kota'];
	$data['kategori'] = $_POST['kategori'];
	$ubah->update("supplier",$data,"kode_supplier = '".$id."'", "home.php?form=supplier");
	break;
}
?>