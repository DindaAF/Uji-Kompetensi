<?php
switch(@$_GET['form']){
case"print-label":
$kode = $_GET['id'];
$jumlah = $_GET['jumlah'];
?>
<div class='row'>
<?php
for ($i=1; $i<=$jumlah;$i++){
	?>
	<div class='col-md-4'>
	<div class='card'>
	No. Inventaris 
	<?= $kode;?>.<?= $i;?></div></div>
	<?php
}
?>
</div>
<?php
break;
case "kartu-inventaris":
		?>
		<div class='row'>
          <div class="col-md-12">
            <div class="card">
              <h4 class="card-title">Kartu Inventaris</h4>

              <div class="card-body">
			    <table id='coba' class="table table-striped table-bordered" cellspacing="0">
              <thead>
                <tr>
                  <th>Kode</th>
				  <th>Lokasi</th>
                  <th style='width:100px;'>Aksi</th>
                </tr>
              </thead>
              <tbody>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from lokasi");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['kode_lokasi'];?></td>
				  <td><?= $data['nama_lokasi'];?></td>
				   <td class="text-center w-0px table-actions">
                       <a class="border btn btn-danger" href="<?php echo "print.php?form=kartu-inventaris&id=".$data['kode_lokasi'];?>">Print</a>
                       
					  </td>
					  </tr>
				  <?php
			  }
			  ?>
              </tbody>
            </table>
          </div>
        </div>
                 </div>
            </div>
          </div>
		  </div>
	

<?php	
case "pencadangan":
?>
<?php
break;	
}
?>