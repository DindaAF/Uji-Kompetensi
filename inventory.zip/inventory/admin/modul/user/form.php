<?php
switch(@$_GET['form']){
	case "user":
?>
<div class='row'>
 <div class="col-lg-6">
            <form enctype='multipart/form-data' class="card" method='post' action='modul/user/page.php?page=tambah-user' enctype='multipart/form-data'>
              <h4 class="card-title fw-400">Tambah Pengguna</h4>

              <div class="card-body">
                <div class="flexbox gap-items-4">
                  <img class="avatar avatar-xl" src="../assets/img/avatar/2.jpg" alt="...">

                  <div class="flex-grow">
                    <div class="form-group file-group">
                  <input type="text" class="form-control file-value file-browser" placeholder="Pilih foto..." readonly>
                  <input type="file" name='foto'>
                </div>

                  </div>
                </div>

                <hr>

                <div class="row">
                  <div class="form-group col-md-6">
                    <label class="text-fader">Nama Lengkap</label>
                    <input class="form-control" type="text" name='nama' required>
                  </div>

                  <div class="form-group col-md-6">
                    <label class="text-fader">username</label>
                    <input class="form-control" type="text" name='username' required>
                  </div>
                </div>


                <div class="form-group">
                  <label class="text-fader">password</label>
                  <input class="form-control" type="password" name='password' required>
                </div>


                <div class="row">
                  <div class="form-group col-md-6">
                    <label class="text-fader">Level</label>
                     <select title='Pilih Level' data-provide="selectpicker" data-live-search="true" name='level' class='form-control'>
                 <?php
				 include "config/koneksi.php";
				 $q3 = $connect ->query("select * from level");
				 while($data3=$q3->fetch_assoc()){
					 echo "<option value=$data3[kode_level]>$data3[level]</option>";
				 }
				 ?>
                </select>
                  </div>

                  <div class="form-group col-md-6">
                    <label class="text-fader">Status</label>
                    <select title='Status' data-provide="selectpicker" data-live-search="true" name='status' class='form-control' required>
					<option>Aktif</option>
					<option>Cuti</option>
                </select></div>
                </div>
                <hr>
              </div>
              <div class="card-body">
                <button class="btn btn-block btn-round btn-bold btn-cyan" type="submit">Tambah</button>
              </div>

            </form>
          </div>
		  <div class='col-md-6'>
  <div class="card">
  <span class="btn btn-cyan" href ="?form=tambah-pengguna"><i class='fa fa-bar'></i> Daftar Pengguna</span>

          <div class="media-list media-list-divided media-list-hover">
<?php
$batas = 5;
$pg = isset( $_GET['pg'] ) ? $_GET['pg'] : "";
if ( empty( $pg ) ) {
$posisi = 0;
$pg = 1;
} else {
$posisi = ( $pg - 1 ) * $batas;
}
include "config/koneksi.php";
$q = $connect->query("select * from user,level where user.kode_level = level.kode_level limit $posisi, $batas");
$no = $posisi + 1;
while($data=$q->fetch_assoc()){

?>
            <div class="media">
              <a class="avatar avatar-lg status-success" href="#">
			  <?php
			  if ($data['foto']==""){
				  ?>
                <img src="../assets/img/avatar/2.jpg" alt="...">
				<?php
			  }else{
			  ?>
              <img src="modul/user/img/<?= $data['foto'];?>" alt="...">
			  <?php
				}?>
              </a>

              <div class="media-body">
                <p>
                  <a class="hover-primary" href="#"><strong><?= $data['nama'];?></strong></a>
                  <small class="sidetitle"><?= $data['status'];?></small>
                </p>
                <p><?= $data['level'];?> </p>

               
              </div>

              <div class="media-right gap-items">
               <a class="media-action lead" href="modul/user/page.php?page=hapus-pengguna&id=<?= $data['id_user'];?>" data-provide="tooltip" title="Hapus"><i class="fa fa-trash"></i></a>
           

              </div>
            </div>
			
			<?php
}
?>
  </div>
		 <ul class="pagination justify-content-center">
		
		<?php
$que = $connect->query("SELECT count(*) as jumlah FROM user");
$cek = $que->fetch_assoc();
$jml_data = $cek['jumlah'];
$JmlHalaman = ceil($jml_data/$batas);
if ( $pg > 1 ) {
$link = $pg-1;
$prev =     "<li class='page-item'>
                <a class='page-link' href='?form=user&pg=$link'>
                  <span class='ti-arrow-left'></span>
                </a>
              </li>";
} else {
$prev =  "<li class='page-item disabled'>
                <a class='page-link' href='?form=user&pg='>
                  <span class='ti-arrow-left'></span>
                </a>
              </li>";
}
$nmr = '';
for ( $i = 1; $i<= $JmlHalaman; $i++ ){
if ( $i == $pg ) {
$nmr .= " <li class='page-item active'><a class='page-link'>$i</a></li>";
} else {
$nmr .= " <li class='page-item'><a class='page-link' href='?form=user&pg=$i'>$i</a></li>";
}
}
if ( $pg < $JmlHalaman ) {
$link = $pg + 1;
$next = "  <li class='page-item'>
                <a class='page-link' href='?form=user&pg=$link'>
                  <span class='ti-arrow-right'></span>
                </a>
              </li>";
} else {
$next = "<li class='page-item disabled'>
                <a class='page-link' href='#'>
                  <span class='ti-arrow-right'></span>
                </a>
              </li>";
}
echo $prev . $nmr . $next;
?>

            </ul>
          </nav>
		 
		  </div>
		  </div>
		</div>
<?php
break;
case "profil":
include"config/koneksi.php";
$q = $connect->query("select * from user,level where
user.kode_level = level.kode_level
and username='$_SESSION[username]'");
$data = $q->fetch_assoc();
?>
<form class="card">
              <h4 class="card-title fw-400">Profil Pengguna</h4>

              <div class="card-body">
                <div class="flexbox gap-items-4">
                  <img class="avatar avatar-xl" src="modul/user/img/<?= $data['foto'];?>" alt="...">

                  <div class="flex-grow">
                    <h5><?= $data['nama'];?></h5>
					  
                  </div>
                </div>

                <hr>

                <div class="row">
                  <div class="form-group col-md-6">
                    <label class="text-fader">Level</label>
                    <input class="form-control" type="text" value="<?= $data['level'];?>" readonly>
                  </div>

                  <div class="form-group col-md-6">
                    <label class="text-fader">Status</label>
                    <input class="form-control" type="text" value="<?= $data['status'];?>" readonly>
                  </div>
                </div>


                <div class="form-group">
                  <label class="text-fader">Username</label>
                  <input class="form-control" type="text" value="<?= $data['username'];?>" readonly>
                </div>



                <hr>
              </div>

          

            </form>
<?php
break;
}
?>