<?php
switch(@$_GET['page']){
	case "tambah-user":
	include "../../engines/proses.php";
	$insert= new proses();
	$counter= new proses();
	$kode = $counter->counter('kode_user',"USR");
	echo $data['nama'] = $_POST['nama'];
	echo $data['username'] = $_POST['username'];
	echo $data['password'] = md5 ($_POST['password']);
	echo $data['foto'] = $_FILES['foto']['name'];
	$path ="img/user".$data['foto'];
	$tmp = $_FILES['foto']['tmp_name'];
	move_uploaded_file($tmp,"img/".$data['foto']);
	echo $data['kode_level'] = $_POST['level'];
	echo $data['status'] = $_POST['status'];
	echo $data['id_user'] = $kode;
	$insert ->insert("user",$data,'../../home.php?form=user');
	break;
	case "hapus-level":
	include "../../engines/proses.php";
	$hapus = new proses;
	$id =$_GET['id'];
	$hapus ->delete("level","kode_level = '".$id."'",'level');
	break;
	case "hapus-pengguna":
	include "../../engines/proses.php";
	$hapus = new proses;
	$id =$_GET['id'];
	$hapus ->delete("user","id_user = '".$id."'",'user');
	break;
	case "ubah-level":
	include "../../engines/proses.php";
	$ubah = new proses;
	$id =$_POST['id'];
	$data['level'] = $_POST['level'];
	$ubah->update("level",$data,"kode_level = '".$id."'", "home.php?form=level");
	break;
}
?>