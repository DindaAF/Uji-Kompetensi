<?php
switch(@$_GET['page']){
	case "tambah-pinjam":
	include "../../engines/proses.php";
	if ($_POST['jumlah']<=0){
		echo"<script>alert('Jumlah barang minimal 1');
		window.location='../../home.php?form=tambah-pinjam&id=$_POST[kode]';</script>";
	}else{
	if ($cek < 0){
	echo"<script>alert('Jumlah barang tersedia hanya $_POST[jml]');
	window.location='../../home.php?form=tambah-pinjam&id=$_POST[kode]';</script>";
	}else{
	$insert= new proses();
	$counter= new proses();
	$kode = $counter->counter('no_pinjam',"PJM");
	$data['kode_barang'] = $_POST['kode'];
	$data['jml_pinjam'] = $_POST['jumlah'];
	$data['keterangan'] = "Belum Kembali";
	$data['tgl_pinjam'] = date("Y-m-d");
	$data['peminjam'] = $_POST['peminjam'];
	$data['tgl_kembali'] = "";
	$data['no_pinjam'] = $kode;
	$cek = $_POST['jml'] - $_POST['jumlah'];
	$insert ->insert("pinjam_barang",$data,"../../home.php?form=detail-pinjam&id=$_POST[kode]");
	}
	}
	break;
	case "pengembalian":
	include "../../engines/proses.php";
	$ubah = new proses;
	$id =$_POST['no'];
	$data['tgl_kembali'] = date("Y-m-d");
	$data['keterangan'] = "Dikembalikan";
	$ubah->update("pinjam_barang",$data,"no_pinjam = '".$id."'", "home.php?form=detail-pinjam&id=$_POST[kode]");
	break;
}
?>