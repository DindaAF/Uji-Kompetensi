<?php
switch ($_GET['form']){
	case"print-label":
     ob_start();
	 $kode = $_GET['id'];
	 $jumlah = $_GET['jumlah'];
?>
<page backtop="0mm" >
<table>
<?php
for ($i=1; $i<=$jumlah;$i++){
	 $msg = $_GET['id'];
	?>
<tr>
<td style="background-color:'#AAAAAA';">
   <qrcode value="<?php echo $msg; ?>" ec="L" style="width: 15mm; border:none;"></qrcode><br>
   </td>
   <td border='1' width='200' align='center'>
	No.Inventaris<br>
	<?= $msg.".".$i; ?>
	</td>
	</tr>
	<tr>
	<td height='7' hidden>
	</td>
	</tr>
	<?php
}
	?>
	</table>
</page>
<?php
     $content = ob_get_clean();

    // convert to PDF
    require_once(dirname(__FILE__).'/engines/html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('P', 'A4', 'fr');
        $html2pdf->pdf->SetDisplayMode('fullpage');
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
        $html2pdf->Output('qrcode.pdf');
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }
break;
case "kartu-inventaris":
session_start();
require('engines/fpdf/fpdf.php');
class PDF extends FPDF
		{
		// Page header
		function Header()
		{
		// Logo
		//$this->Image('logo.png',10,6,30);
		// Arial bold 15
		$this->SetFont('Times','B',15);
		// Move to the right
		$this->Cell(80);
		// Title
		$this->Cell(30,10,'Kartu Inventaris',0,0,'C');
		$this->SetFont('Times','',10);
		$this->Ln(7);
		$this->Cell(0,10,'Sarana Prasarana',0,0,'C');
		// Line break
		$this->Ln(20);
		}

		// Page footer
		function Footer()
		{
		// Position at 1.5 cm from bottom
		$this->SetY(-15);
		// Arial italic 8
		$this->SetFont('Arial','I',8);
		// Page number
		$this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
		}
		}
		include "config/koneksi.php";
		// Instanciation of inherited class
		$pdf = new PDF();
		$pdf->AliasNbPages();
		$pdf->AddPage();
		$pdf->SetFont('Times','B',12);
		$pdf->Cell(120,0,"Distribusi Barang",0,"R");
		$pdf->SetFont('Times','',11);
		$pdf->Cell(30,0,"Dicetak pada",0,"R");
		$cetak = date ("Y-m-d"). date (" h:i:s");
		$pdf->Cell(10,0,": ".$cetak,0,"R");
		$pdf->Ln(10);
		$quu = $connect->query("select * from lokasi where kode_lokasi='$_GET[id]'");
		$dr = $quu->fetch_assoc();
		$pdf->Cell(45,0,"Kode Lokasi");
		$pdf->Cell(80,0,": ".$dr['kode_lokasi']);
		$pdf->Ln(5);
		$pdf->Cell(45,0,"Lokasi");
		$pdf->Cell(80,0,": ".$dr['nama_lokasi']);
		$pdf->Ln(10);
		$no=1;
		$pdf->SetFont('Times','B',11);
		$pdf->Cell(50,7,"Kode",1,0,"C");
        $pdf->Cell(40,7,"Nama",1,0,"C");
        $pdf->Cell(45,7,"spesifikasi",1,0,"C");
        $pdf->Cell(15,7,"Jumlah",1,0,"C");
        $pdf->Cell(40,7,"kondisi",1,0,"C");
        $pdf->Ln();
		$pdf->SetFont('Times','',11);
		$qq = $connect->query("select * from distribusi_barang,barang
								where distribusi_barang.kode_barang=barang.kode_barang
								and lokasi='$_GET[id]' order by kode_distribusi ASC");
		while($row = $qq->fetch_assoc()){
			$pdf->Cell(50,7,"".$row['kode_distribusi'],1,0,"C");
			$pdf->Cell(40,7,"".$row['nama_barang'],1,0,"C");
			$pdf->Cell(45,7,"".$row['spesifikasi'],1,0,"C");
			$pdf->Cell(15,7,"".$row['jumlah'],1,0,"C");
			$pdf->Cell(40,7,"".$row['kondisi'],1,0,"C");
            $pdf->Ln(7);
		}
		$result_total=$connect->query("select sum(jumlah) as total from distribusi_barang where lokasi='$_GET[id]'");
        $total=$result_total->fetch_assoc();
        $pdf->Cell(135,7,"TOTAL",1,0,"C");
        $pdf->Cell(15,7,"".$total['total'],1,0,"C"); 
		$pdf->Cell(40,7,"",1,0);
        $pdf->Ln(20);
		$pdf->Cell(15,7,"",0,0);
		$pdf->Cell(135,0,"Penanggungjawab,",0,"L");
		$pdf->Cell(15,0,"Wakasarpras,",0,"R");
		$pdf->Ln(30);
		$pdf->Cell(15,7,"",0,0);
		$pdf->Cell(135,0,"________________",0,"L");
		$pdf->Cell(15,0,"_______________",0,"R");
		$pdf->Ln(15);
		$pdf->Cell(85,0,"",0,"R");
		$pdf->Cell(15,0,"Yayasan / SDM,",0,"R");
		$pdf->Ln(30);
		$pdf->Cell(80,0,"",0,"R");
		$pdf->Cell(15,0,"__________________",0,"R");
		//mutasi
		$pdf->AliasNbPages();
		$pdf->AddPage();
		$pdf->SetFont('Times','B',12);
		$pdf->Cell(120,0,"Mutasi barang",0,"R");
		$pdf->SetFont('Times','',11);
		$pdf->Cell(30,0,"Dicetak pada",0,"R");
		$cetak = date ("Y-m-d"). date (" h:i:s");
		$pdf->Cell(10,0,": ".$cetak,0,"R");
		$pdf->Ln(10);
		$quu = $connect->query("select * from lokasi where kode_lokasi='$_GET[id]'");
		$dr = $quu->fetch_assoc();
		$pdf->Cell(45,0,"Kode Lokasi");
		$pdf->Cell(80,0,": ".$dr['kode_lokasi']);
		$pdf->Ln(5);
		$pdf->Cell(45,0,"Lokasi");
		$pdf->Cell(80,0,": ".$dr['nama_lokasi']);
		$pdf->Ln(10);
		$no=1;
		$pdf->SetFont('Times','B',11);
		$pdf->Cell(50,7,"Kode",1,0,"C");
        $pdf->Cell(40,7,"Nama",1,0,"C");
        $pdf->Cell(45,7,"spesifikasi",1,0,"C");
        $pdf->Cell(15,7,"Jumlah",1,0,"C");
        $pdf->Cell(40,7,"Penerima",1,0,"C");
        $pdf->Ln();
		$pdf->SetFont('Times','',11);
		$qq = $connect->query("select * from keluar_barang,barang,lokasi
								where keluar_barang.kode_barang=barang.kode_barang
								and keluar_barang.penerima = lokasi.kode_lokasi
								and kode_distribusi like '%".$_GET['id']."%' order by kode_distribusi ASC");
		while($row = $qq->fetch_assoc()){
			$pdf->Cell(50,7,"".$row['kode_distribusi'],1,0,"C");
			$pdf->Cell(40,7,"".$row['nama_barang'],1,0,"C");
			$pdf->Cell(45,7,"".$row['spesifikasi'],1,0,"C");
			$pdf->Cell(15,7,"".$row['jumlah_keluar'],1,0,"C");
			  $pdf->Cell(40,7,"".$row['nama_lokasi'],1,0,"C");
            $pdf->Ln(7);
		}
		$result_total=$connect->query("select sum(jumlah_keluar) as total from keluar_barang where kode_distribusi like '%".$_GET['id']."%'");
        $total=$result_total->fetch_assoc();
        $pdf->Cell(135,7,"TOTAL",1,0,"C");
        $pdf->Cell(15,7,"".$total['total'],1,0,"C"); 
		$pdf->Cell(40,7,"",1,0);
		 $pdf->Ln(20);
		$pdf->Cell(15,7,"",0,0);
		$pdf->Cell(135,0,"Penanggungjawab,",0,"L");
		$pdf->Cell(15,0,"Wakasarpras,",0,"R");
		$pdf->Ln(30);
		$pdf->Cell(15,7,"",0,0);
		$pdf->Cell(135,0,"________________",0,"L");
		$pdf->Cell(15,0,"_______________",0,"R");
		$pdf->Ln(15);
		$pdf->Cell(85,0,"",0,"R");
		$pdf->Cell(15,0,"Yayasan / SDM,",0,"R");
		$pdf->Ln(30);
		$pdf->Cell(80,0,"",0,"R");
		$pdf->Cell(15,0,"__________________",0,"R");
		$pdf->Output();
		break;
case "barang":
$tgl = date ("Y-m-d h:i:s");
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=data_barang_$tgl.xls");
?>
<center><h3>Data Barang </h3></center>
<table border='1'>
                <tr>
                  <th>Kode</th>
				  <th>Nama</th>
                  <th>Spesifikasi</th>
                  <th>Kategori</th>
                  <th>Jenis</th>
                  <th>Jumlah</th>
                </tr>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from barang");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['kode_barang'];?></td>
				  <td><?= $data['nama_barang'];?></td>
				   <td><?= $data['spesifikasi'];?></td>
				   <td><?= $data['kategori'];?></td>
				   <td><?= $data['jenis_barang'];?></td>
				   <td><?= $data['jumlah_total'];?></td>
					  </tr>
				  <?php
			  }
		  ?>
            </table>
<?php
case "distribusi":
$tgl = date ("Y-m-d-h-i-s");
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=data_distribusi_$tgl.xls");
?>
<table border="1">
              <thead>
                <tr>
                  <th>Kode</th>
				  <th>Nama Barang</th>
				  <th>Lokasi</th>
                  <th>Jumlah</th>
                  <th>Kondisi</th>
                </tr>
              </thead>
              <tbody>
			  <?php
			  include "config/koneksi.php";
			  $q = $connect->query("select * from distribusi_barang,lokasi,barang where
			  distribusi_barang.kode_barang =  barang.kode_barang and
			  distribusi_barang.lokasi=lokasi.kode_lokasi and distribusi_barang.id_masuk_barang='$_GET[id]'");
			  while ($data = $q->fetch_assoc()){
				  ?>
				  <tr>
				  <td><?= $data['kode_distribusi'];?></td>
				  <td><?= $data['nama_barang'];?></td>
				  <td><?= $data['nama_lokasi'];?></td>
				   <td><?= $data['jumlah'];?></td>
				   <td><?= $data['kondisi'];?></td>
					  </tr>
				  <?php
			  }
			  ?>
              </tbody>
            </table>
<?php
break;
case "buku-panduan":
    require_once(dirname(__FILE__).'/engines/html2pdf/html2pdf.class.php');

    // get the HTML
     ob_start();
     include(dirname('__FILE__').'/engines/about.php');
    $content = ob_get_clean();

    try
    {
        // init HTML2PDF
        $html2pdf = new HTML2PDF('P', 'A4', 'fr', true, 'UTF-8', array(0, 0, 0, 0));

        // display the full page
        $html2pdf->pdf->SetDisplayMode('fullpage');

        // convert
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));

        // add the automatic index
        $html2pdf->createIndex('Daftar Isi', 30, 12, false, true, 2);

        // send the PDF
        $html2pdf->Output('about.pdf');
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }
break;
}
?>