<!DOCTYPE html>
<?php
session_start();
if (!isset($_SESSION['username'])){
	header ("location:login.php");
}else{
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive admin dashboard and web application ui kit. ">
    <meta name="keywords" content="blank, starter">

    <title>SIM Inventaris</title>

    <!-- Styles -->
    <link href="../assets/css/core.min.css" rel="stylesheet">
    <link href="../assets/css/app.min.css" rel="stylesheet">
    <link href="../assets/css/style.min.css" rel="stylesheet">

    <!-- Favicons -->
    <link rel="apple-touch-icon" href="../assets/img/apple-touch-icon.png">
    <link rel="icon" href="../assets/img/favicon.png">
  </head>

  <body>

    <!-- Preloader -->
    <div class="preloader">
      <div class="spinner-dots">
        <span class="dot1"></span>
        <span class="dot2"></span>
        <span class="dot3"></span>
      </div>
    </div>


    <!-- Sidebar -->
    <aside class="sidebar sidebar-icons-right sidebar-icons-boxed sidebar-expand-lg ">
      <header class="sidebar-header bg-cyan">
          <a href="?form=home"><span><font size='4'><i class="ti-reddit"></i> SIM Inventaris</font></span></a>
        <span class="logo">
		</span>
        <span class="sidebar-toggle-fold"></span>
      </header>

      <nav class="sidebar-navigation">
        <ul class="menu">

          <li class="menu-category">Menu</li>

          <li class="menu-item <?php if ($_GET['form']=='home'){
			echo "bg-cyan";
			}?>">
            <a class="menu-link" href="?form=home">
              <span class="icon fa fa-home"></span>
              <span class="title">Beranda</span>
            </a>
          </li>
		  <?php
		  include "config/koneksi.php";
		  $q = $connect->query("select * from hak_akses,menu where menu.kode_menu=hak_akses.kode_menu and kode_level='$_SESSION[level]' 
								order by menu ASC");
		  while($datam=$q->fetch_assoc()){
			  if ($datam['menu']=='Supplier'){
			  ?>
		 <li class="menu-item <?php if ($_GET['form']=='supplier' or $_GET['form']=='ubah-supplier'){
			echo "bg-cyan";
			}?>">
            <a class="menu-link" href="?form=supplier">
              <span class="icon fa fa-pencil"></span>
              <span class="title">Supplier</span>
            </a>
          </li>
		  <?php
			  }
			  if ($datam['menu']=='Peminjaman'){
			  ?>
           <li class="menu-item <?php if ($_GET['form']=='detail-pinjam' or $_GET['form']=='peminjaman' or $_GET['form']=='tambah-pinjam'){
			echo "bg-cyan";
			}?>">
            <a class="menu-link" href="?form=peminjaman">
              <span class="icon fa fa-shopping-cart"></span>
              <span class="title">Peminjaman</span>
            </a>
          </li>
		  
		  <?php
			  }
			  if ($datam['menu']=='Barang'){
			  ?>
		  
		   <li class="menu-item <?php if ($_GET['form']=='barang' or $_GET['form']=='tambah-barang'){
			echo "bg-cyan";
			}?>">
            <a class="menu-link" href="?form=barang">
              <span class="icon fa fa-shopping-basket"></span>
              <span class="title">Barang</span>
            </a>
          </li>
		  <?php
			  }
			  if ($datam['menu']=='Distribusi'){
			  ?>
		  
		   <li class="menu-item <?php if ($_GET['form']=='distribusi' 
		   or $_GET['form']=='distribusi'
		   or $_GET['form']=='detail-barang' 
		   or $_GET['form']=='mutasi'
		   or $_GET['form']=='tambah-distribusi'
		   ){
			echo "bg-cyan";
			}?>">
            <a class="menu-link" href="?form=distribusi">
              <span class="icon fa fa-share-square-o"></span>
              <span class="title">Distribusi</span>
            </a>
          </li>
		  <?php
			  }
			  if ($datam['menu']=='Kartu Inventaris'){
			  ?>
		  
		   <li class="menu-item <?php if ($_GET['form']=='kartu-inventaris' or $_GET['form']=='laporan'){
			echo "bg-cyan";
			}?>">
            <a class="menu-link" href="?form=kartu-inventaris">
              <span class="icon fa fa-id-card"></span>
              <span class="title">Kartu Inventaris</span>
            </a>
          </li>
		  
		  <?php
			  }
			  if ($datam['menu']=='Pengaturan'){
			  ?>
		  
          <li class="menu-item <?php if ($_GET['form']=='hak-akses' or $_GET['form']=='level'){
			echo "bg-cyan";
			}?>">
            <a class="menu-link" href="#">
              <span class="icon ti-settings"></span>
              <span class="title">Pengaturan</span>
              <span class="arrow"></span>
            </a>

            <ul class="menu-submenu">
              <li class="menu-item">
                <a class="menu-link" href="?form=hak-akses">
                  <span class="dot"></span>
                  <span class="title">Hak Akses</span>
                </a>
              </li>

              <li class="menu-item">
                <a class="menu-link" href="?form=level">
                  <span class="dot"></span>
                  <span class="title">Level</span>
                </a>
              </li>
            </ul>
          </li>
		  <?php
			  }
			  if ($datam['menu']=='Master'){
			  ?>
		  
          <li class="menu-item <?php if ($_GET['form']=='lokasi'
		  or $_GET['form']=='user'
		   or $_GET['form']=='sumber-dana'
		   or $_GET['form']=='kategori'
		  ){
			echo "bg-cyan";
			}?>">
            <a class="menu-link" href="#">
              <span class="icon ti-server"></span>
              <span class="title">Master</span>
              <span class="arrow"></span>
            </a>

            <ul class="menu-submenu">
                <li class="menu-item">
                <a class="menu-link" href="?form=user">
                  <span class="dot"></span>
                  <span class="title">Pengguna</span>
                </a>
              </li>

              <li class="menu-item">
                <a class="menu-link" href="?form=lokasi">
                  <span class="dot"></span>
                  <span class="title">Lokasi</span>
                </a>
              </li>
			  
             <li class="menu-item">
                <a class="menu-link" href="?form=sumber-dana">
                  <span class="dot"></span>
                  <span class="title">Sumber dana</span>
                </a>
              </li>
			 <li class="menu-item">
                <a class="menu-link" href="?form=kategori">
                  <span class="dot"></span>
                  <span class="title">Kategori Barang</span>
                </a>
              </li>
            </ul>
          </li>
		  <?php
			  }
		  }
			  ?>
            </ul>
          </li>
        </ul>
      </nav>
    </aside>
    <!-- END Sidebar -->


    <!-- Topbar -->
       <header class="topbar topbar-invers">
          <div class="topbar-left">
            <button class="topbar-btn sidebar-toggler">&#9776;</button>
            
 <a class="topbar-btn d-none d-md-block" href="#" data-provide="fullscreen tooltip" title="Fullscreen">
          <i class="material-icons fullscreen-default">fullscreen</i>
          <i class="material-icons fullscreen-active">fullscreen_exit</i>
        </a>
           </div>
          <div class="topbar-right">
		  

		<?php
					  $q=$connect->query("select * from user where username='$_SESSION[username]'");
					  $d= $q->fetch_assoc();
					  ?>
            <ul class="topbar-btns">
              <li class="dropdown">
                <span class="topbar-btn" data-toggle="dropdown"><img class="avatar avatar-sm" src="
				<?php
				if($d['foto']==""){
				echo "../assets/img/avatar/2.jpg";
				}else{
				echo "modul/user/img/$d[foto]";
				}
				?>
				" alt="..."></span>
                <div class="dropdown-menu dropdown-menu-right">
                  <a class="dropdown-item" href="?form=profil"><i class="ti-user"></i> Profil</a>
                  <a class="dropdown-item" href="print.php?form=buku-panduan'"><i class="ti-help"></i> Bantuan</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="modul/sistem/page.php?page=logout"><i class="ti-power-off"></i> Keluar</a>
                </div>
              </li>
			<div class="topbar-divider"></div>
			<?php
			$q = $connect->query("select * from hak_akses,menu 
			where menu.kode_menu=hak_akses.kode_menu 
			and menu='Peminjaman' 
			and hak_akses.kode_level='$_SESSION[level]'");
		  $datam=$q->fetch_assoc();
			  if ($datam['menu']=='Peminjaman'){
				  ?>
              <!-- Notifications -->
			  <?php
			include"config/koneksi.php";
			$posisi = '0';
			$batas = '3';
			$query = $connect->query("select * from pinjam_barang,barang
			where barang.kode_barang = pinjam_barang.kode_barang
			and keterangan='Diminta' order by no_pinjam DESC limit $posisi,$batas");
			$cek = $query->num_rows;
			if($cek<1){
				?>
				<li class="dropdown">
					<span class="topbar-btn" data-toggle="dropdown"><i class="ti-bell"></i></span>
					<div class="dropdown-menu dropdown-menu-right">
					<div class="media-list media-list-hover media-list-divided media-sm">
                    <a class="media disabled">
                      <span class="avatar bg-danger"><i class="ti-list"></i></span>
                      <div class="media-body">
                        <p>Belum Ada Notifikasi</p>
                       </div>
                    </a>
                  </div>
				<?php
			}else{
				?>
				<li class="dropdown">
					<span class="topbar-btn has-new" data-toggle="dropdown"><i class="ti-bell"></i></span>
					<div class="dropdown-menu dropdown-menu-right">
				<?php
			while($dat=$query->fetch_assoc()){
			?>
                  <div class="media-list media-list-hover media-list-divided media-sm">
                    <a class="media media new" href="?form=tambah-pengembalian&id=<?= $dat['no_pinjam'];?>">
                      <span class="avatar bg-danger"><i class="ti-list"></i></span>
                      <div class="media-body">
                        <p><?php echo "Peminjaman ".$dat['nama_barang']." (".$dat['no_pinjam'].") meminta pengembalian";?></p>
                       </div>
                    </a>
                  </div>
			<?php
			}
			}
			?>
                 

                </div>
              </li>
			 
              <!-- END Notifications -->
 <div class="topbar-divider">
  <?php
			  }
			  ?></div>
            </ul>

          </div>
        </header>
    <!-- END Topbar -->


    <!-- Main container -->
    <main>
	
      <div class="main-content">

<?php
include "modul/supplier/form.php";
include "modul/sistem/form.php";
include "modul/barang/form.php";
include "modul/pinjam/form.php";
include "modul/laporan/form.php";
include "modul/user/form.php";
?>


      </div><!--/.main-content -->


      <!-- Footer -->
      <footer class="site-footer">
        <div class="row">
          <div class="col-md-6">
            <p class="text-center text-md-left"><a href=""></a></p>
          </div>

          <div class="col-md-6">
            <ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
              <li class="nav-item">
                <a class="nav-link" href="#">Ketentuan Layanan</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="print.php?form=buku-panduan">Bantuan</a>
              </li>
            </ul>
          </div>
        </div>
      </footer>
      <!-- END Footer -->

    </main>
    <!-- END Main container -->



    <!-- Global quickview -->
    <div id="qv-global" class="quickview" data-url="../assets/data/quickview-global.html">
      <div class="spinner-linear">
        <div class="line"></div>
      </div>
    </div>
    <!-- END Global quickview -->



    <!-- Scripts -->
    <script src="../assets/js/core.min.js" data-provide="chartjs"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/script.min.js"></script>
	
	
  </body>
   <script>
      app.ready(function() {

        // ==============================================
        // Pie chart
        //
        new Chart($("#chart-pie"), {
          type: 'pie',

          // Data
          //
          data: {
            labels: [
              "Tetap",
              "Pinjaman",
            ],
            datasets: [
              {
                data: [
				<?php
			include "config/koneksi.php";
			$q = $connect->query("select sum(jumlah_total) as jumlah from barang where jenis_barang='Tetap'");
			$data= $q->fetch_assoc();
			echo $data['jumlah'];
			?>, <?php
			include "config/koneksi.php";
			$q = $connect->query("select sum(jumlah_total) as jumlah from barang where jenis_barang='Pinjaman'");
			$data= $q->fetch_assoc();
			echo $data['jumlah'];
			?>],
                backgroundColor: [
                  'rgba(255,99,132,1)',
                  'rgba(54, 162, 235, 1)',
                ]
              }]
          },

          // Options
          //
          options: {
            responsive: true
          }
        });
		
		 new Chart($("#dana"), {
          type: 'pie',

          // Data
          //
          data: {
            labels: [
			<?php
			include "config/koneksi.php";
			$q = $connect->query("select * from sumber_dana");
			while($data= $q->fetch_assoc()){
				echo "'".$data['nama_sumber']."',";
			}
			?>
            ],
            datasets: [
              {
                data: [
				<?php
			include "config/koneksi.php";
			$qd = $connect->query("select * from sumber_dana");
			while($datad= $qd->fetch_assoc()){
			$q = $connect->query("select sum(jumlah_masuk) as jumlah from masuk_barang where sumber_dana='$datad[kode_dana]'");
			$data= $q->fetch_assoc();
			echo $data['jumlah'].",";
			}
			?>],
                backgroundColor: [
                  'rgba(255,99,132,1)',
                  'rgba(54, 162, 235, 1)',
                ]
              }]
          },

          // Options
          //
          options: {
            responsive: false
          }
        });
      });
    </script>
</html>
<?php
}
?>