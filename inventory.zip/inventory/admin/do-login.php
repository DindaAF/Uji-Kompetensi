<?php
include ("config/koneksi.php");
$pass = md5 ($_POST['password']);
$query= $connect->query("select * from user where username='$_POST[username]' and password='$pass' and status='Aktif'");
$cek= $query->num_rows;
$da = $query->fetch_assoc();
if($cek>0){
	session_start();
	$_SESSION['username']=$_POST['username'];
	$_SESSION['level']=$da['kode_level'];
	header ("location:home.php?form=home");
}else{
	echo"<script>alert ('Kombinasi username & password tidak cocok!');
	window.location='login.php';</script>";
}
?>