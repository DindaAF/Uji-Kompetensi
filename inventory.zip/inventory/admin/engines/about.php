<style type="text/css">
<!--
    table.page_header {width: 100%; border: none; background-color: #DDDDFF; border-bottom: solid 1mm #AAAADD; padding: 2mm }
    table.page_footer {width: 100%; border: none; background-color: #DDDDFF; border-top: solid 1mm #AAAADD; padding: 2mm}
    div.note {border: solid 1mm #DDDDDD;background-color: #EEEEEE; padding: 2mm; border-radius: 2mm; width: 100%; }
    ul.main { width: 95%; list-style-type: square; }
    ul.main li { padding-bottom: 2mm; }
    h1 { text-align: center; font-size: 20mm}
    h3 { text-align: center; font-size: 14mm}
-->
</style>
<page backtop="14mm" backbottom="14mm" backleft="10mm" backright="10mm" style="font-size: 12pt">
    <page_header>
        <table class="page_header">
            <tr>
                <td style="width: 50%; text-align: left">
                    Buku Panduan
                </td>
                <td style="width: 50%; text-align: right">
                    SIM Inventaris v1.0
                </td>
            </tr>
        </table>
    </page_header>
    <page_footer>
        <table class="page_footer">
            <tr>
                <td style="width: 33%; text-align: left;">
                    Proyek Ujian Praktek Kejuruan
                </td>
                <td style="width: 34%; text-align: center">
                    Halaman [[page_cu]]/[[page_nb]]
                </td>
                <td style="width: 33%; text-align: right">
                    &copy;Victor Oktavian Kuncoro 2018
                </td>
            </tr>
        </table>
    </page_footer>
    <bookmark title="Halaman Depan" level="0" ></bookmark>
    <br><br><br><br><br><br><br><br>
    <h1>SIM Inventaris</h1>
    <h3>v1.0</h3><br>
    <br><br><br><br><br>
    <div style="text-align: center; width: 100%;">
        <br>
        <img src="img/banner.png" alt="SIM Inventaris" style="width: 120mm">
        <br>
    </div>
    <br><br><br><br><br>
    <div class="note">
        Proyek ini diciptakan guna menyelesaikan ujian praktek kejuruan Rekayasa Perangkat Lunak<br>
        <br>
       Adapun aplikasi yang dibuat adalah Sistem Informasi Manajemen Inventaris Sarana Prasarana SMK<br>
        <br>
       Aplikasi ini bertujuan untuk membantu memanajemen pendataan sarana prasarana SMK<br>
        <br>
        Dibuat Oleh Victor Oktavian Kuncoro XII-Rekayasa Perangkat Lunak
		<BR>SMK BAGIMU NEGERIKU SEMARANG</div>
</page>
<page pageset="old">
    <bookmark title="Daftar Isi" level="0" ></bookmark>
    <!-- here will be the automatic index -->
</page>
<page pageset="old">
    <bookmark title="Sistem" level="0" ></bookmark>
    <bookmark title="Pengaturan" level="1" ></bookmark>
    <bookmark title="Level" level="2" ></bookmark>
    <div class="note">
       Panduan Level<br>
    </div>
    <br>
   Level merupakan sebuah menu untuk mengelola level pengguna aplikasi SIM Inventaris dengan fitur dinamis tambah, ubah dan hapus data level<br>
    <bookmark title="Hak Akses" level="2" ></bookmark>
	<br><br><br>
    <div class="note">
       Panduan Hak Akses<br>
    </div>
	<br>
    Hak Akses adalah sebuah menu untuk mengatur batasan akses setiap level pengguna SIM Inventaris
</page>
<page pageset="old">
    <bookmark title="Master" level="1" ></bookmark>
     <bookmark title="Pengguna" level="2" ></bookmark>
    <div class="note">
       Panduan Pengguna<br>
    </div>
    <br>
   Menu untuk memanajemen pengguna SIM Inventaris
</page>