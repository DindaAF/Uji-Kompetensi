<?php
class proses{
	public function logout(){
		session_start();
		session_destroy();
		header ('location:login.php');
	}
	public function insert( $database , $data,$alamat)
    {
		include "../../config/koneksi.php";
        $row = array();
        $nilai = array();
        foreach ( $data as $kolom =>$value )
               {
            $row[] = $kolom;
            $nilai[] = "'".$value."'";
        }
 
        $q = $this->result = $connect->query("INSERT INTO ". $database ."(". implode(',' ,$row) .")
                        VALUES (". implode(',' , $nilai) .")");
		header ("location:$alamat");
     }
	public function update($table , $data , $where, $alamat)
      {
		  include "../../config/koneksi.php";
        foreach ( $data as $kolom => $row )
        {
            $set[]= $kolom."='".$row."'" ;
        }
        $set = implode(',',$set);
        $query = "UPDATE ".$table." SET ".$set." WHERE ".$where ;
        $connect->query($query);
		header ("location:../../$alamat");
		
    }
    public function delete($table , $where, $alamat)
    {
		include"../../config/koneksi.php";
        $connect->query("DELETE FROM ".$table." WHERE ".$where);
		header("location:../../home.php?form=$alamat");
    }
	public function counter($row, $string){
		include "../../config/koneksi.php";
		$query = $connect->query("select * from counter");
		$data=$query->fetch_assoc();
			$jumlah= $data[$row] + 1;
			if($jumlah<10){
			$kode = $string."00". $jumlah;
			}else if ($jumlah<100){
			$kode = $string."0". $jumlah;
			}else if ($jumlah<1000){
			$kode = $string."". $jumlah;
			}
			return ($kode);
		}
}
?>