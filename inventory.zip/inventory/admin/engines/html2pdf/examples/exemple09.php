<?php
/**
 * HTML2PDF Librairy - example
 *
 * HTML => PDF convertor
 * distributed under the LGPL License
 *
 * @author      Laurent MINGUET <webmaster@html2pdf.fr>
 *
 */

$nom = "D031.B017.M016.L006.S002";
$nom = substr(preg_replace('/[^a-zA-Z0-9]/isU', '', $nom), 0, 26);
ob_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" >
        <title>Exemple d'auto génération de PDF</title>
    </head>
    <body>
<?php


?>
<barcode type="C39" value="<?php echo strtoupper($nom); ?>" style="color: #000000" ></barcode>
<br>
<br>
<?php
        $content = ob_get_clean();
        require_once(dirname(__FILE__).'/../html2pdf.class.php');
        try
        {
            $html2pdf = new HTML2PDF('P', 'A4', 'fr');
            $html2pdf->writeHTML($content);
            $html2pdf->Output('exemple09.pdf');
            exit;
        }
        catch(HTML2PDF_exception $e) {
            echo $e;
            exit;
        }
?>
    </body>
</html>