<?php
     ob_start();
     $msg = "D031.B017.M016.L006.S002";
?>
<page backtop="0mm" >
<table>
<tr>
<td style="background-color:'#AAAAAA';">
   <qrcode value="<?php echo $msg; ?>" ec="L" style="width: 15mm; border:none;"></qrcode><br>
   </td>
   <td border='1' width='200' align='center'>
	No.Inventaris<br>
	D031.B017.M016.L006.S002
	</td>
	</tr>
	<tr>
	<td height='7' hidden>
	</td>
	</tr>
	</table>
</page>
<?php
     $content = ob_get_clean();

    // convert to PDF
    require_once(dirname(__FILE__).'/../html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('P', 'A4', 'fr');
        $html2pdf->pdf->SetDisplayMode('fullpage');
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
        $html2pdf->Output('qrcode.pdf');
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }
