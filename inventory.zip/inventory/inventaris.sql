-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 30 Apr 2021 pada 03.23
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventaris`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `kode_barang` varchar(8) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `spesifikasi` varchar(35) NOT NULL,
  `kategori` varchar(25) NOT NULL,
  `jumlah_total` int(5) NOT NULL,
  `jenis_barang` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`kode_barang`, `nama_barang`, `spesifikasi`, `kategori`, `jumlah_total`, `jenis_barang`) VALUES
('B028', 'Monitor', 'LG', 'K001', 25, 'Tetap'),
('B029', 'Mouse', 'microsoft', 'K002', 0, 'Tetap'),
('B031', 'Proyektor', 'LG', 'K001', 0, 'Peminjaman'),
('B032', 'kabel roll', 'LG', 'K001', 0, 'Peminjaman'),
('B033', 'tes', 'pinjam', 'K001', 50, 'Pinjaman');

--
-- Trigger `barang`
--
DELIMITER $$
CREATE TRIGGER `count_barang` AFTER INSERT ON `barang` FOR EACH ROW begin
update counter set kode_barang = kode_barang + 1;
insert into log values('',concat('barang baru ',new.nama_barang,'  ditambahkan'),'');
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `counter`
--

CREATE TABLE `counter` (
  `kode_supplier` int(11) NOT NULL,
  `id_masuk_barang` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `kode_barang` int(11) NOT NULL,
  `no_pinjam` int(11) NOT NULL,
  `id_barang_keluar` int(11) NOT NULL,
  `kode_level` int(11) NOT NULL,
  `kode_menu` int(11) NOT NULL,
  `kode_distribusi` int(11) NOT NULL,
  `kode_user` int(11) NOT NULL,
  `kode_lokasi` int(11) NOT NULL,
  `kode_dana` int(11) NOT NULL,
  `kode_kategori` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `counter`
--

INSERT INTO `counter` (`kode_supplier`, `id_masuk_barang`, `id_user`, `kode_barang`, `no_pinjam`, `id_barang_keluar`, `kode_level`, `kode_menu`, `kode_distribusi`, `kode_user`, `kode_lokasi`, `kode_dana`, `kode_kategori`) VALUES
(28, 34, 0, 33, 10, 13, 21, 12, 52, 14, 12, 5, 12);

-- --------------------------------------------------------

--
-- Struktur dari tabel `distribusi_barang`
--

CREATE TABLE `distribusi_barang` (
  `kode_distribusi` varchar(50) NOT NULL,
  `kode_barang` varchar(10) NOT NULL,
  `id_masuk_barang` varchar(10) NOT NULL,
  `lokasi` varchar(50) NOT NULL,
  `jumlah` varchar(10) NOT NULL,
  `kondisi` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `distribusi_barang`
--

INSERT INTO `distribusi_barang` (`kode_distribusi`, `kode_barang`, `id_masuk_barang`, `lokasi`, `jumlah`, `kondisi`) VALUES
('D052.B028.M031.L006.S002', 'B028', 'M031', 'L006', '25', 'Baik');

--
-- Trigger `distribusi_barang`
--
DELIMITER $$
CREATE TRIGGER `distribusi` AFTER INSERT ON `distribusi_barang` FOR EACH ROW begin
INSERT INTO stok(kode_distribusi,jumlah_masuk,jumlah_keluar,keterangan,total_barang) VALUES(New.kode_distribusi,New.jumlah,'0','',new.jumlah);
update counter set kode_distribusi = kode_distribusi + 1;
end
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `hapus distribusi` BEFORE DELETE ON `distribusi_barang` FOR EACH ROW begin
delete from keluar_barang where kode_distribusi=old.kode_distribusi;
delete from stok where kode_distribusi=old.kode_distribusi;
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `hak_akses`
--

CREATE TABLE `hak_akses` (
  `id` int(11) NOT NULL,
  `kode_level` varchar(11) NOT NULL,
  `kode_menu` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `hak_akses`
--

INSERT INTO `hak_akses` (`id`, `kode_level`, `kode_menu`) VALUES
(1, 'LVL-017', 'LVL-002'),
(4, 'LVL-017', 'LVL-003'),
(5, 'LVL-019', 'LVL-003'),
(6, 'LVL-019', 'LVL-004'),
(7, 'LVL-019', 'LVL-005'),
(8, 'LVL-019', 'LVL-006'),
(11, 'LVL-019', 'LVL-008'),
(12, 'LVL-017', 'LVL-004'),
(13, 'LVL-019', 'LVL-002'),
(14, 'LVL-019', 'LVL009'),
(15, 'LVL-019', 'LVL011'),
(16, 'LVL-019', 'LVL012'),
(17, 'LVL-018', 'LVL-007'),
(18, 'LVL-018', 'LVL009'),
(19, 'LVL021', 'LVL-002'),
(20, 'LVL-019', 'LVL-007');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `kode_kategori` varchar(12) NOT NULL,
  `kategori` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`kode_kategori`, `kategori`) VALUES
('K001', 'Elektronika'),
('K002', 'Komputer'),
('K003', 'Meubel'),
('K004', 'Alat');

--
-- Trigger `kategori`
--
DELIMITER $$
CREATE TRIGGER `count_kategori` AFTER INSERT ON `kategori` FOR EACH ROW begin
update counter set kode_kategori = kode_kategori + 1;
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `keluar_barang`
--

CREATE TABLE `keluar_barang` (
  `id_barang_keluar` varchar(8) NOT NULL,
  `id_masuk_barang` varchar(10) NOT NULL,
  `kode_distribusi` varchar(50) NOT NULL,
  `kode_barang` varchar(30) NOT NULL,
  `tgl_keluar` date NOT NULL,
  `penerima` varchar(35) NOT NULL,
  `jumlah_keluar` int(8) NOT NULL,
  `keperluan` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Trigger `keluar_barang`
--
DELIMITER $$
CREATE TRIGGER `count_keluar_barang` AFTER INSERT ON `keluar_barang` FOR EACH ROW begin
update counter set id_barang_keluar = id_barang_keluar + 1;
update distribusi_barang set jumlah = jumlah - new.jumlah_keluar where kode_distribusi = new.kode_distribusi;
update stok set jumlah_keluar = jumlah_keluar + new.jumlah_keluar, total_barang = jumlah_masuk - jumlah_keluar where kode_distribusi= new.kode_distribusi;
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `level`
--

CREATE TABLE `level` (
  `kode_level` varchar(8) NOT NULL,
  `level` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `level`
--

INSERT INTO `level` (`kode_level`, `level`) VALUES
('LVL-017', 'Yayasan'),
('LVL-018', 'Guru'),
('LVL-019', 'Wakasarpras'),
('LVL021', 'Admin Gudang');

--
-- Trigger `level`
--
DELIMITER $$
CREATE TRIGGER `count_level` AFTER INSERT ON `level` FOR EACH ROW begin
update counter set kode_level = kode_level + 1;
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `log`
--

CREATE TABLE `log` (
  `id` int(11) NOT NULL,
  `kegiatan` varchar(100) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `log`
--

INSERT INTO `log` (`id`, `kegiatan`, `waktu`) VALUES
(1, 'barang baru <b>CPU </b> ditambahkan', '0000-00-00 00:00:00'),
(2, 'barang baru <b>Monitor </b> ditambahkan', '0000-00-00 00:00:00'),
(3, 'barang baru <b>Keyboard </b> ditambahkan', '0000-00-00 00:00:00'),
(4, 'barang baru <b>Mouse </b> ditambahkan', '0000-00-00 00:00:00'),
(5, 'barang baru <b>Proyektor </b> ditambahkan', '0000-00-00 00:00:00'),
(6, 'barang baru Meja  ditambahkan', '0000-00-00 00:00:00'),
(7, 'barang baru Kursi  ditambahkan', '0000-00-00 00:00:00'),
(8, 'barang baru AC  ditambahkan', '0000-00-00 00:00:00'),
(9, 'barang baru Komputer  ditambahkan', '0000-00-00 00:00:00'),
(10, 'barang baru laptop  ditambahkan', '0000-00-00 00:00:00'),
(11, 'barang baru coba  ditambahkan', '0000-00-00 00:00:00'),
(12, 'barang baru lepi  ditambahkan', '0000-00-00 00:00:00'),
(13, 'barang baru Monitor  ditambahkan', '0000-00-00 00:00:00'),
(14, 'barang baru Mouse  ditambahkan', '0000-00-00 00:00:00'),
(15, 'barang baru Proyektor  ditambahkan', '0000-00-00 00:00:00'),
(16, 'barang baru Proyektor  ditambahkan', '0000-00-00 00:00:00'),
(17, 'barang baru kabel roll  ditambahkan', '0000-00-00 00:00:00'),
(18, 'barang baru tes  ditambahkan', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `lokasi`
--

CREATE TABLE `lokasi` (
  `kode_lokasi` varchar(8) NOT NULL,
  `nama_lokasi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `lokasi`
--

INSERT INTO `lokasi` (`kode_lokasi`, `nama_lokasi`) VALUES
('L006', 'RPL'),
('L007', 'Multimedia'),
('L008', 'TKBB'),
('L009', 'TKRO'),
('L010', 'JB'),
('L012', 'Gudang A');

--
-- Trigger `lokasi`
--
DELIMITER $$
CREATE TRIGGER `count_lokasi` BEFORE INSERT ON `lokasi` FOR EACH ROW begin
update counter set kode_lokasi = kode_lokasi + 1;
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `masuk_barang`
--

CREATE TABLE `masuk_barang` (
  `id_masuk_barang` varchar(8) NOT NULL,
  `kode_barang` varchar(8) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `jumlah_masuk` int(8) NOT NULL,
  `kode_supplier` varchar(10) NOT NULL,
  `sumber_dana` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `masuk_barang`
--

INSERT INTO `masuk_barang` (`id_masuk_barang`, `kode_barang`, `tgl_masuk`, `jumlah_masuk`, `kode_supplier`, `sumber_dana`) VALUES
('M031', 'B028', '2018-02-16', 25, 'S027', 'S002'),
('M032', 'B030', '2018-02-16', 10, 'S027', 'S003'),
('M034', 'B033', '2018-02-16', 50, 'S027', 'S003');

--
-- Trigger `masuk_barang`
--
DELIMITER $$
CREATE TRIGGER `count_masuk_barang` BEFORE INSERT ON `masuk_barang` FOR EACH ROW begin
update counter set id_masuk_barang = id_masuk_barang + 1;
end
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `hapus_masuk_barang` BEFORE DELETE ON `masuk_barang` FOR EACH ROW begin
delete from distribusi_barang where id_masuk_barang=old.id_masuk_barang;
delete from stok where kode_distribusi like concat('%',old.id_masuk_barang,'%');
update barang set jumlah_total = jumlah_total - old.jumlah_masuk where kode_barang= old.kode_barang;
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `menu`
--

CREATE TABLE `menu` (
  `kode_menu` varchar(8) NOT NULL,
  `menu` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `menu`
--

INSERT INTO `menu` (`kode_menu`, `menu`) VALUES
('LVL-002', 'Barang'),
('LVL-003', 'Supplier'),
('LVL-004', 'Distribusi'),
('LVL-005', 'Master'),
('LVL-006', 'Mutasi'),
('LVL-007', 'Peminjaman'),
('LVL009', 'Kartu Inventaris'),
('LVL011', 'Pengaturan');

--
-- Trigger `menu`
--
DELIMITER $$
CREATE TRIGGER `count_menu` AFTER INSERT ON `menu` FOR EACH ROW begin
update counter set kode_menu = kode_menu + 1;
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pinjam_barang`
--

CREATE TABLE `pinjam_barang` (
  `no_pinjam` varchar(8) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `kode_barang` varchar(8) NOT NULL,
  `jml_pinjam` int(7) NOT NULL,
  `peminjam` varchar(35) NOT NULL,
  `tgl_kembali` date NOT NULL,
  `keterangan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pinjam_barang`
--

INSERT INTO `pinjam_barang` (`no_pinjam`, `tgl_pinjam`, `kode_barang`, `jml_pinjam`, `peminjam`, `tgl_kembali`, `keterangan`) VALUES
('PJM007', '2018-02-16', 'B033', 53, 'victor', '2018-02-16', 'Dikembalikan'),
('PJM008', '2018-02-16', 'B033', 40, 'victor', '2018-02-16', 'Dikembalikan'),
('PJM009', '2018-02-16', 'B033', 5, 'v', '2018-02-16', 'Dikembalikan'),
('PJM010', '2018-02-16', 'B033', 5, 'victor', '2018-02-16', 'Dikembalikan');

--
-- Trigger `pinjam_barang`
--
DELIMITER $$
CREATE TRIGGER `count_pinjam` AFTER INSERT ON `pinjam_barang` FOR EACH ROW begin
update counter set no_pinjam = no_pinjam +1;
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `stok`
--

CREATE TABLE `stok` (
  `kode_distribusi` varchar(50) NOT NULL,
  `jumlah_masuk` int(7) NOT NULL,
  `jumlah_keluar` int(7) NOT NULL,
  `total_barang` int(8) NOT NULL,
  `keterangan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `stok`
--

INSERT INTO `stok` (`kode_distribusi`, `jumlah_masuk`, `jumlah_keluar`, `total_barang`, `keterangan`) VALUES
('D052.B028.M031.L006.S002', 25, 0, 25, '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sumber_dana`
--

CREATE TABLE `sumber_dana` (
  `kode_dana` varchar(10) NOT NULL,
  `nama_sumber` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `sumber_dana`
--

INSERT INTO `sumber_dana` (`kode_dana`, `nama_sumber`) VALUES
('S002', 'Yayasan'),
('S003', 'BOS'),
('S004', 'Donatur');

--
-- Trigger `sumber_dana`
--
DELIMITER $$
CREATE TRIGGER `count_dana` AFTER INSERT ON `sumber_dana` FOR EACH ROW begin
update counter set kode_dana = kode_dana + 1;
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `supplier`
--

CREATE TABLE `supplier` (
  `kode_supplier` varchar(5) NOT NULL,
  `nama_supplier` varchar(35) NOT NULL,
  `alamat_supplier` varchar(100) NOT NULL,
  `telp_supplier` varchar(25) NOT NULL,
  `kota_supplier` varchar(20) NOT NULL,
  `kategori` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `supplier`
--

INSERT INTO `supplier` (`kode_supplier`, `nama_supplier`, `alamat_supplier`, `telp_supplier`, `kota_supplier`, `kategori`) VALUES
('S026', 'Microsoft', 'boyolali', '0839748', 'Boyolali', 'K002'),
('S027', 'LG', 'semarang', '089345', 'Semarang', 'K001'),
('S028', 'Columbia', 'salatiga', '0858347', 'Semarang', 'K003');

--
-- Trigger `supplier`
--
DELIMITER $$
CREATE TRIGGER `count_supplier` AFTER INSERT ON `supplier` FOR EACH ROW begin
update counter set kode_supplier = kode_supplier + 1;
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` varchar(8) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(500) NOT NULL,
  `kode_level` varchar(8) NOT NULL,
  `foto` varchar(500) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `nama`, `username`, `password`, `kode_level`, `foto`, `status`) VALUES
('USR013', 'budi budi', 'budi', '00dfc53ee86af02e742515cdcf075ed3', 'LVL-019', '', 'Aktif'),
('USR014', 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'LVL-019', '', 'Aktif');

--
-- Trigger `user`
--
DELIMITER $$
CREATE TRIGGER `count_user` AFTER INSERT ON `user` FOR EACH ROW begin
update counter set kode_user = kode_user + 1;
end
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`kode_barang`);

--
-- Indeks untuk tabel `distribusi_barang`
--
ALTER TABLE `distribusi_barang`
  ADD PRIMARY KEY (`kode_distribusi`);

--
-- Indeks untuk tabel `hak_akses`
--
ALTER TABLE `hak_akses`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`kode_kategori`);

--
-- Indeks untuk tabel `keluar_barang`
--
ALTER TABLE `keluar_barang`
  ADD PRIMARY KEY (`id_barang_keluar`);

--
-- Indeks untuk tabel `level`
--
ALTER TABLE `level`
  ADD PRIMARY KEY (`kode_level`);

--
-- Indeks untuk tabel `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `lokasi`
--
ALTER TABLE `lokasi`
  ADD PRIMARY KEY (`kode_lokasi`);

--
-- Indeks untuk tabel `masuk_barang`
--
ALTER TABLE `masuk_barang`
  ADD PRIMARY KEY (`id_masuk_barang`);

--
-- Indeks untuk tabel `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`kode_menu`);

--
-- Indeks untuk tabel `pinjam_barang`
--
ALTER TABLE `pinjam_barang`
  ADD PRIMARY KEY (`no_pinjam`);

--
-- Indeks untuk tabel `stok`
--
ALTER TABLE `stok`
  ADD PRIMARY KEY (`kode_distribusi`);

--
-- Indeks untuk tabel `sumber_dana`
--
ALTER TABLE `sumber_dana`
  ADD PRIMARY KEY (`kode_dana`);

--
-- Indeks untuk tabel `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`kode_supplier`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `hak_akses`
--
ALTER TABLE `hak_akses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `log`
--
ALTER TABLE `log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
