<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive admin dashboard and web application ui kit. ">
    <meta name="keywords" content="coming, soon, landing">

    <title>SIM Inventaris</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,300i" rel="stylesheet">

    <!-- Styles -->
    <link href="assets/css/core.min.css" rel="stylesheet">
    <link href="assets/css/app.min.css" rel="stylesheet">
    <link href="assets/css/style.min.css" rel="stylesheet">

    <!-- Favicons -->
    <link rel="apple-touch-icon" href="../assets/img/apple-touch-icon.png">
    <link rel="icon" href="assets/img/favicon.png">
  </head>

  <body class="min-h-fullscreen bg-img p-70" style="background-image: url(admin/img/bg.jpg)" data-overlay="6">

    <h2 class="text-uppercase text-white fs-50 d-none d-md-block">
      <span class="fs-70 fw-900">SIM Inventaris</span><br>
      <span>V1.0</span>
      <span class="text-white fs-70"> </span>
    </h2>


    <br><br><br>

   

    <h2 class="text-uppercase text-white fs-30 d-md-none">
      <span class="fs-50 fw-900">SIM Inventaris</span><br>
      <span>V1.0</span>
      <span class="text-primary fs-50"> </span>
    </h2>
<center>
  
          <label class="text-white fw-400">Sistem Informasi Manajemen Inventaris Sarana Prasarana SMK</label>
       
       <br>
          <a class="btn btn-bold btn-outline btn-light" href='user/'>Peminjaman</a>
		  <a class="btn btn-bold btn-outline btn-light" href="admin/">Admin</a>
       
     



    <!-- Scripts -->
    <script src="assets/js/core.min.js"></script>
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/script.min.js"></script>

  </body>
</html>

